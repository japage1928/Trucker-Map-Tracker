import { Switch, Route, Redirect } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/components/ThemeProvider";
import { useAuth } from "@/hooks/use-auth";
import { Navigation } from "@/components/Navigation";
import { Loader2 } from "lucide-react";

// Pages
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/Dashboard";
import VehiclesPage from "@/pages/Vehicles";
import TripsPage from "@/pages/Trips";
import NavigatePage from "@/pages/Navigate";
import AuthPage from "@/pages/Auth";

function ProtectedRoute({ component: Component }: { component: React.ComponentType }) {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background text-primary">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  if (!user) {
    return <Redirect to="/auth" />;
  }

  return (
    <div className="flex flex-col md:flex-row min-h-screen bg-background text-foreground font-sans selection:bg-primary selection:text-primary-foreground">
      <Navigation />
      <main className="flex-1 overflow-y-auto h-[calc(100vh-80px)] md:h-screen pb-20 md:pb-0">
        <Component />
      </main>
    </div>
  );
}

function Router() {
  const { user, isLoading } = useAuth();

  if (isLoading) return null; // Or a splash screen

  return (
    <Switch>
      <Route path="/auth">
        {user ? <Redirect to="/" /> : <AuthPage />}
      </Route>
      
      <Route path="/">
        <ProtectedRoute component={Dashboard} />
      </Route>
      
      <Route path="/vehicles">
        <ProtectedRoute component={VehiclesPage} />
      </Route>

      <Route path="/trips">
        <ProtectedRoute component={TripsPage} />
      </Route>

      <Route path="/navigate/:tripId?">
        {/* Navigate page renders full-screen without sidebar */}
        <NavigatePage />
      </Route>

      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <Router />
          <Toaster />
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
