import { useQuery } from "@tanstack/react-query";
import { api } from "@shared/routes";

interface PoiFilters {
  lat?: number;
  lng?: number;
  radius?: number;
  type?: string;
}

export function usePois(filters?: PoiFilters) {
  return useQuery({
    queryKey: [api.pois.list.path, filters],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (filters?.lat) params.append("lat", String(filters.lat));
      if (filters?.lng) params.append("lng", String(filters.lng));
      if (filters?.radius) params.append("radius", String(filters.radius));
      if (filters?.type) params.append("type", filters.type);

      const url = `${api.pois.list.path}?${params.toString()}`;
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch POIs");
      return api.pois.list.responses[200].parse(await res.json());
    },
  });
}
