import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";

interface UserSettings {
  theme: string | null;
  totalMilesDriven: number | null;
  totalTimeDriven: number | null;
}

export function useSettings() {
  return useQuery<UserSettings>({
    queryKey: ["/api/settings"],
  });
}

export function useUpdateSettings() {
  return useMutation({
    mutationFn: async (settings: Partial<UserSettings>) => {
      const res = await apiRequest("PUT", "/api/settings", settings);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
    },
  });
}

export function useDeleteAccount() {
  return useMutation({
    mutationFn: async () => {
      await apiRequest("DELETE", "/api/account");
    },
  });
}
