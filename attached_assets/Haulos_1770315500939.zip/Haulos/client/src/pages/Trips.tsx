import { useTrips, useCreateTrip, useDeleteTrip } from "@/hooks/use-trips";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogTrigger, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { MapPin, Navigation, Clock, Calendar, Trash2, Loader2 } from "lucide-react";
import { useState } from "react";
import { useVehicles } from "@/hooks/use-vehicles";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Map } from "@/components/Map";
import { useToast } from "@/hooks/use-toast";

const tripFormSchema = z.object({
  name: z.string().min(1, "Trip name is required"),
  vehicleId: z.string().min(1, "Please select a vehicle"),
  startAddress: z.string().min(1, "Origin is required"),
  endAddress: z.string().min(1, "Destination is required"),
});

type TripFormData = z.infer<typeof tripFormSchema>;

// Geocode address using backend API (proxies to Nominatim)
const geocodeAddress = async (address: string): Promise<{ lat: number; lng: number; address: string }> => {
  const response = await fetch(
    `/api/geocode?address=${encodeURIComponent(address)}`,
    { credentials: 'include' }
  );
  
  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.message || 'Geocoding failed');
  }
  
  return response.json();
};

// Get real route distance and duration using OSRM backend
const calculateRoute = async (
  startLat: number, startLng: number, 
  endLat: number, endLng: number
): Promise<{ distance: number; duration: number }> => {
  const response = await fetch(
    `/api/route?startLat=${startLat}&startLng=${startLng}&endLat=${endLat}&endLng=${endLng}`,
    { credentials: 'include' }
  );
  
  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.message || 'Route calculation failed');
  }
  
  return response.json();
};

// Format duration in hours and minutes
const formatDuration = (minutes: number): string => {
  const hours = Math.floor(minutes / 60);
  const mins = minutes % 60;
  if (hours === 0) return `${mins}m`;
  if (mins === 0) return `${hours}h`;
  return `${hours}h ${mins}m`;
};

export default function TripsPage() {
  const { data: trips, isLoading } = useTrips();
  const { data: vehicles } = useVehicles();
  const createTrip = useCreateTrip();
  const deleteTrip = useDeleteTrip();
  const [open, setOpen] = useState(false);
  const [isCreating, setIsCreating] = useState(false);
  const { toast } = useToast();

  const form = useForm<TripFormData>({
    resolver: zodResolver(tripFormSchema),
    defaultValues: {
      name: "",
      vehicleId: "",
      startAddress: "",
      endAddress: "",
    }
  });

  const onSubmit = async (data: TripFormData) => {
    setIsCreating(true);
    try {
      // Get real coordinates from Nominatim
      const [startLocation, endLocation] = await Promise.all([
        geocodeAddress(data.startAddress),
        geocodeAddress(data.endAddress)
      ]);
      
      // Get real route distance and duration from OSRM
      const routeData = await calculateRoute(
        startLocation.lat, startLocation.lng,
        endLocation.lat, endLocation.lng
      );
      
      const tripData = {
        name: data.name,
        vehicleId: parseInt(data.vehicleId),
        startLocation,
        endLocation,
        status: "planned",
        distance: routeData.distance,
        duration: routeData.duration,
      };

      await createTrip.mutateAsync(tripData as any);
      setOpen(false);
      form.reset();
      toast({ title: "Trip created", description: `${routeData.distance} miles, approximately ${formatDuration(routeData.duration)}` });
    } catch (error: any) {
      const message = error?.message || "Failed to create trip";
      toast({ title: "Error", description: message, variant: "destructive" });
    } finally {
      setIsCreating(false);
    }
  };

  const handleDeleteTrip = async (tripId: number, tripName: string) => {
    try {
      await deleteTrip.mutateAsync(tripId);
      toast({ title: "Trip deleted", description: `"${tripName}" has been removed` });
    } catch (error) {
      toast({ title: "Error", description: "Failed to delete trip", variant: "destructive" });
    }
  };

  return (
    <div className="p-4 md:p-8 max-w-7xl mx-auto space-y-8">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl md:text-4xl font-display font-bold text-foreground">TRIP PLANNER</h1>
          <p className="text-muted-foreground">Schedule and optimize your routes.</p>
        </div>

        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button className="bg-primary text-primary-foreground font-bold hover:bg-yellow-400">
              CREATE NEW TRIP
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-secondary border-border text-foreground sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle className="text-2xl font-display text-primary">PLAN NEW ROUTE</DialogTitle>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 mt-4">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                     <FormItem>
                       <FormLabel>Trip Name</FormLabel>
                       <FormControl>
                         <Input {...field} placeholder="e.g. Dallas to Chicago" className="bg-background border-muted" />
                       </FormControl>
                       <FormMessage />
                     </FormItem>
                  )}
                />
                
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="startAddress"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Origin City</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="City, State" className="bg-background border-muted" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="endAddress"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Destination City</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="City, State" className="bg-background border-muted" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="vehicleId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Assigned Vehicle</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={String(field.value)}>
                        <FormControl>
                          <SelectTrigger className="bg-background border-muted">
                            <SelectValue placeholder="Select vehicle" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {vehicles?.map(v => (
                            <SelectItem key={v.id} value={String(v.id)}>{v.name} ({v.type})</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Button 
                  type="submit" 
                  disabled={isCreating}
                  size="lg"
                  className="w-full font-bold mt-4"
                  data-testid="button-generate-route"
                >
                  {isCreating ? (
                    <>
                      <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                      CALCULATING ROUTE...
                    </>
                  ) : (
                    'GENERATE ROUTE'
                  )}
                </Button>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Main Content Area - Split View */}
      <div className="grid lg:grid-cols-2 gap-6 h-[calc(100vh-200px)]">
        {/* Trip List */}
        <div className="space-y-4 overflow-y-auto pr-2 custom-scrollbar">
          {isLoading ? (
            <p className="text-muted-foreground">Loading trips...</p>
          ) : trips?.map(trip => (
            <Card key={trip.id} className="bg-secondary border-muted hover:border-primary/50 cursor-pointer group transition-all">
              <CardContent className="p-4">
                <div className="flex justify-between items-start mb-3 gap-2">
                  <h3 className="text-lg font-bold text-white group-hover:text-primary transition-colors flex-1" data-testid={`text-trip-name-${trip.id}`}>{trip.name}</h3>
                  <div className="flex items-center gap-2">
                    <span className={`px-2 py-0.5 text-xs font-bold rounded uppercase ${
                      trip.status === 'active' ? 'bg-green-500/20 text-green-500' : 'bg-muted text-muted-foreground'
                    }`}>
                      {trip.status}
                    </span>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDeleteTrip(trip.id, trip.name);
                      }}
                      data-testid={`button-delete-trip-${trip.id}`}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                
                <div className="relative pl-6 space-y-4 mb-4">
                   {/* Timeline Line */}
                   <div className="absolute left-2 top-2 bottom-2 w-0.5 bg-muted-foreground/30 border-l border-dashed border-muted-foreground/50"></div>
                   
                   <div className="relative">
                      <div className="absolute -left-[21px] top-1 h-3 w-3 rounded-full bg-primary ring-4 ring-secondary"></div>
                      <p className="text-sm font-bold text-white">{(trip.startLocation as any).address}</p>
                   </div>
                   <div className="relative">
                      <div className="absolute -left-[21px] top-1 h-3 w-3 rounded-full bg-muted-foreground ring-4 ring-secondary"></div>
                      <p className="text-sm font-bold text-white">{(trip.endLocation as any).address}</p>
                   </div>
                </div>

                <div className="flex items-center gap-4 text-xs text-muted-foreground border-t border-muted pt-3">
                  <div className="flex items-center gap-1" data-testid={`text-trip-distance-${trip.id}`}>
                    <Navigation className="h-3 w-3" />
                    {trip.distance} mi
                  </div>
                  <div className="flex items-center gap-1" data-testid={`text-trip-duration-${trip.id}`}>
                    <Clock className="h-3 w-3" />
                    {formatDuration(trip.duration || 0)}
                  </div>
                  <div className="flex items-center gap-1 ml-auto">
                    <Calendar className="h-3 w-3" />
                    {new Date(trip.createdAt!).toLocaleDateString()}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
          
          {trips?.length === 0 && (
            <div className="text-center py-12 border-2 border-dashed border-muted rounded-xl">
              <p className="text-muted-foreground">No upcoming trips scheduled.</p>
            </div>
          )}
        </div>

        {/* Map View */}
        <div className="bg-secondary border border-muted rounded-xl overflow-hidden shadow-2xl relative hidden lg:block">
           <div className="absolute inset-0 z-0">
             <Map 
               center={[39.8283, -98.5795]} 
               zoom={4}
               route={trips?.[0] ? [
                 [(trips[0].startLocation as any).lat, (trips[0].startLocation as any).lng],
                 [(trips[0].endLocation as any).lat, (trips[0].endLocation as any).lng]
               ] : undefined}
             />
           </div>
           
           {/* Floating Info Panel */}
           <div className="absolute bottom-4 left-4 right-4 bg-secondary/90 backdrop-blur border border-muted p-4 rounded-lg shadow-lg z-[1000]">
             <div className="flex items-center gap-2 text-primary font-bold text-sm uppercase mb-1">
               <MapPin className="h-4 w-4" /> TRUCK ROUTE OPTIMIZED
             </div>
             <p className="text-xs text-muted-foreground">
               Showing legal routes for standard 13'6" height, 80k lbs semi-trailer. Low bridges avoided.
             </p>
           </div>
        </div>
      </div>
    </div>
  );
}
