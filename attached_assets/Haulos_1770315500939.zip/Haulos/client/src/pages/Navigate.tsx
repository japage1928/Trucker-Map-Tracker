import { useTrips } from "@/hooks/use-trips";
import { useVehicles } from "@/hooks/use-vehicles";
import { useAuth } from "@/hooks/use-auth";
import { Map } from "@/components/Map";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { HamburgerMenu } from "@/components/HamburgerMenu";
import { 
  ArrowLeft, 
  Navigation2, 
  Volume2, 
  VolumeX, 
  Fuel, 
  Coffee, 
  AlertTriangle,
  MapPin,
  Clock,
  ChevronRight,
  Loader2,
  Bath,
  ParkingCircle,
  ChevronDown,
  ChevronUp,
  Truck,
  Plus,
  Minus
} from "lucide-react";
import { Link, useParams, Redirect } from "wouter";
import { useState, useMemo } from "react";
import { useToast } from "@/hooks/use-toast";

type POIType = "fuel" | "rest" | "bathroom" | "parking";

interface UpcomingStop {
  id: string;
  name: string;
  type: POIType;
  distanceAhead: number; // miles ahead on route
  timeAhead: number; // minutes ahead
  amenities: string[];
  truckAccessible: boolean;
}

// Simulated POIs along route - in production these would come from real-time API
const generateRouteAheadPOIs = (tripDistance: number, scanDistance: number): UpcomingStop[] => {
  const stops: UpcomingStop[] = [];
  const maxDistance = Math.min(tripDistance, scanDistance);
  
  // Generate realistic truck stops along the route
  const truckStops = [
    { offset: 12, name: "Pilot Travel Center", type: "fuel" as POIType, amenities: ["Diesel", "DEF", "Showers", "Parking"] },
    { offset: 18, name: "Rest Area - Mile 18", type: "rest" as POIType, amenities: ["Restrooms", "Vending", "Truck Parking"] },
    { offset: 25, name: "Love's Travel Stop", type: "fuel" as POIType, amenities: ["Diesel", "DEF", "Restaurant", "Showers"] },
    { offset: 32, name: "Flying J", type: "fuel" as POIType, amenities: ["Diesel", "DEF", "Scales", "Parking"] },
    { offset: 45, name: "Rest Area - Mile 45", type: "rest" as POIType, amenities: ["Restrooms", "Picnic Area", "Truck Parking"] },
    { offset: 58, name: "TA Truck Stop", type: "fuel" as POIType, amenities: ["Diesel", "Restaurant", "Showers", "Laundry"] },
    { offset: 72, name: "Petro Stopping Center", type: "fuel" as POIType, amenities: ["Diesel", "DEF", "Iron Skillet", "Parking"] },
    { offset: 85, name: "Rest Area - Mile 85", type: "rest" as POIType, amenities: ["Restrooms", "Vending", "Truck Parking"] },
    { offset: 95, name: "Sapp Bros.", type: "fuel" as POIType, amenities: ["Diesel", "DEF", "Restaurant", "Parking"] },
  ];
  
  for (const stop of truckStops) {
    if (stop.offset <= maxDistance) {
      stops.push({
        id: `poi-${stop.offset}`,
        name: stop.name,
        type: stop.type,
        distanceAhead: stop.offset,
        timeAhead: Math.round(stop.offset * 1.1), // ~1.1 min per mile for trucks
        amenities: stop.amenities,
        truckAccessible: true
      });
    }
  }
  
  return stops;
};

const POIIcon = ({ type, className }: { type: POIType; className?: string }) => {
  switch (type) {
    case "fuel":
      return <Fuel className={className} />;
    case "rest":
      return <Coffee className={className} />;
    case "bathroom":
      return <Bath className={className} />;
    case "parking":
      return <ParkingCircle className={className} />;
  }
};

const POIColor = (type: POIType) => {
  switch (type) {
    case "fuel": return "text-green-500";
    case "rest": return "text-amber-500";
    case "bathroom": return "text-blue-500";
    case "parking": return "text-purple-500";
  }
};

export default function NavigatePage() {
  const { user, isLoading: authLoading } = useAuth();
  const params = useParams<{ tripId: string }>();
  const { data: trips, isLoading: tripsLoading } = useTrips();
  const { data: vehicles } = useVehicles();
  const [isMuted, setIsMuted] = useState(false);
  const [scanDistance, setScanDistance] = useState(30); // Default 30 mile lookahead
  const [activeFilter, setActiveFilter] = useState<POIType | null>(null);
  const [showUpcoming, setShowUpcoming] = useState(true);
  const [addedStops, setAddedStops] = useState<string[]>([]); // Track POIs added to navigation
  const { toast } = useToast();
  
  // Auth check
  if (authLoading) {
    return (
      <div className="h-screen flex items-center justify-center bg-background">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }
  
  if (!user) {
    return <Redirect to="/auth" />;
  }
  
  const tripId = params.tripId ? parseInt(params.tripId) : null;
  const trip = tripId ? trips?.find(t => t.id === tripId) : trips?.[0];
  const vehicle = trip && vehicles?.find(v => v.id === trip.vehicleId);

  // Generate upcoming POIs based on scan distance
  const upcomingStops = useMemo(() => {
    if (!trip) return [];
    const stops = generateRouteAheadPOIs(trip.distance || 100, scanDistance);
    if (activeFilter) {
      return stops.filter(s => s.type === activeFilter);
    }
    return stops;
  }, [trip, scanDistance, activeFilter]);

  // Extend scan when filter button is tapped
  const handleFilterTap = (type: POIType) => {
    if (activeFilter === type) {
      // Double tap extends scan further
      setScanDistance(prev => Math.min(prev + 30, 200));
    } else {
      setActiveFilter(type);
      setScanDistance(50); // Extend scan when selecting a filter
    }
  };

  const clearFilter = () => {
    setActiveFilter(null);
    setScanDistance(30);
  };

  // Increase scan distance
  const increaseScanDistance = () => {
    setScanDistance(prev => {
      const newDistance = Math.min(prev + 30, 200);
      if (newDistance > prev) {
        toast({
          title: `Scanning ${newDistance} miles ahead`,
          description: newDistance === 200 ? "Maximum scan distance reached" : "Tap + to scan further",
        });
      }
      return newDistance;
    });
  };

  // Decrease scan distance
  const decreaseScanDistance = () => {
    setScanDistance(prev => {
      const newDistance = Math.max(prev - 30, 30);
      if (newDistance < prev) {
        toast({
          title: `Scanning ${newDistance} miles ahead`,
          description: newDistance === 30 ? "Minimum scan distance" : "Tap - to reduce range",
        });
      }
      return newDistance;
    });
  };

  // Add a POI as a stop/waypoint on the route
  const addStopToRoute = (stop: UpcomingStop) => {
    if (addedStops.includes(stop.id)) {
      // Remove if already added
      setAddedStops(prev => prev.filter(id => id !== stop.id));
      toast({
        title: "Stop removed",
        description: `${stop.name} removed from your route`,
      });
    } else {
      // Add the stop
      setAddedStops(prev => [...prev, stop.id]);
      toast({
        title: "Stop added to route",
        description: `${stop.name} - Exit in ${stop.distanceAhead} miles`,
      });
    }
  };

  if (tripsLoading) {
    return (
      <div className="h-screen flex items-center justify-center bg-background">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!trip) {
    return (
      <div className="h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <Navigation2 className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
          <h2 className="text-xl font-bold text-foreground mb-2" data-testid="text-no-trip">No Active Trip</h2>
          <p className="text-muted-foreground mb-4">Start a trip to begin navigation.</p>
          <Link href="/trips">
            <Button data-testid="button-plan-trip">Plan a Trip</Button>
          </Link>
        </div>
      </div>
    );
  }

  const remainingDistance = trip.distance || 0;
  const remainingMinutes = trip.duration || 0;
  const hours = Math.floor(remainingMinutes / 60);
  const minutes = remainingMinutes % 60;

  return (
    <div className="h-screen flex flex-col bg-background relative">
      {/* Full Screen Map */}
      <div className="absolute inset-0 z-0">
        <Map 
          center={[(trip.startLocation as any).lat, (trip.startLocation as any).lng]}
          zoom={8}
          route={[
            [(trip.startLocation as any).lat, (trip.startLocation as any).lng],
            [(trip.endLocation as any).lat, (trip.endLocation as any).lng]
          ]}
        />
      </div>

      {/* Top Navigation Bar */}
      <div className="relative z-10 bg-background/95 backdrop-blur border-b border-border p-3 flex items-center justify-between gap-4">
        <div className="flex items-center gap-1">
          <HamburgerMenu />
          <Link href="/">
            <Button variant="ghost" size="icon" data-testid="button-back">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
        </div>
        
        <div className="flex-1 text-center">
          <h1 className="font-display font-bold text-lg text-foreground truncate" data-testid="text-trip-name">
            {trip.name}
          </h1>
          {vehicle && (
            <p className="text-xs text-muted-foreground" data-testid="text-vehicle-name">{vehicle.name}</p>
          )}
        </div>

        <Button 
          variant="ghost" 
          size="icon"
          onClick={() => setIsMuted(!isMuted)}
          data-testid="button-mute"
        >
          {isMuted ? <VolumeX className="h-5 w-5" /> : <Volume2 className="h-5 w-5" />}
        </Button>
      </div>

      {/* Turn-by-Turn Direction Card */}
      <div className="relative z-10 p-4">
        <Card className="bg-primary text-primary-foreground shadow-2xl">
          <CardContent className="p-4">
            <div className="flex items-center gap-4">
              <div className="bg-primary-foreground/20 rounded-lg p-3">
                <ChevronRight className="h-8 w-8" />
              </div>
              <div className="flex-1">
                <p className="text-sm opacity-80" data-testid="text-next-turn-distance">In 2.4 miles</p>
                <p className="text-xl font-bold" data-testid="text-next-turn-instruction">Continue on I-40 West</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Route Ahead Panel - Predictive Navigation */}
      <div className="relative z-10 flex-1 overflow-hidden flex flex-col">
        <div className="mx-4 flex items-center justify-between bg-secondary/90 backdrop-blur rounded-t-lg px-4 py-2 border-t border-x border-border">
          <button 
            onClick={() => setShowUpcoming(!showUpcoming)}
            className="flex items-center gap-2"
            data-testid="button-toggle-upcoming"
          >
            <Truck className="h-4 w-4 text-primary" />
            <span className="text-sm font-bold text-foreground">
              ROUTE AHEAD
            </span>
          </button>
          <div className="flex items-center gap-3">
            {/* Scan distance controls */}
            <div className="flex items-center gap-1 bg-background/50 rounded-lg px-2 py-1">
              <button
                onClick={decreaseScanDistance}
                disabled={scanDistance <= 30}
                className="p-1 rounded hover:bg-background disabled:opacity-30 disabled:cursor-not-allowed"
                data-testid="button-decrease-scan"
              >
                <Minus className="h-4 w-4 text-primary" />
              </button>
              <span className="text-xs font-bold text-primary min-w-[50px] text-center" data-testid="text-scan-distance">
                {scanDistance} mi
              </span>
              <button
                onClick={increaseScanDistance}
                disabled={scanDistance >= 200}
                className="p-1 rounded hover:bg-background disabled:opacity-30 disabled:cursor-not-allowed"
                data-testid="button-increase-scan"
              >
                <Plus className="h-4 w-4 text-primary" />
              </button>
            </div>
            <button onClick={() => setShowUpcoming(!showUpcoming)}>
              {showUpcoming ? <ChevronDown className="h-4 w-4" /> : <ChevronUp className="h-4 w-4" />}
            </button>
          </div>
        </div>

        {showUpcoming && (
          <div className="mx-4 bg-secondary/90 backdrop-blur rounded-b-lg border-x border-b border-border overflow-hidden">
            {/* Active Filter Indicator */}
            {activeFilter && (
              <div className="px-4 py-2 bg-background/50 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <POIIcon type={activeFilter} className={`h-4 w-4 ${POIColor(activeFilter)}`} />
                  <span className="text-sm text-foreground capitalize">{activeFilter} stops only</span>
                </div>
                <Button variant="ghost" size="sm" onClick={clearFilter} data-testid="button-clear-filter">
                  Clear
                </Button>
              </div>
            )}

            {/* Upcoming Stops List - Click to add to route */}
            <div className="max-h-40 overflow-y-auto">
              {upcomingStops.length > 0 ? (
                upcomingStops.slice(0, 4).map((stop) => {
                  const isAdded = addedStops.includes(stop.id);
                  return (
                    <button 
                      key={stop.id}
                      onClick={() => addStopToRoute(stop)}
                      className={`w-full px-4 py-3 border-b border-border/50 last:border-0 flex items-center gap-3 text-left hover:bg-background/30 active:bg-background/50 transition-colors ${isAdded ? 'bg-primary/10 border-l-2 border-l-primary' : ''}`}
                      data-testid={`poi-item-${stop.id}`}
                    >
                      <div className={`p-2 rounded-lg ${isAdded ? 'bg-primary/20' : 'bg-background/50'} ${POIColor(stop.type)}`}>
                        <POIIcon type={stop.type} className="h-4 w-4" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <p className="text-sm font-bold text-foreground truncate">{stop.name}</p>
                          {isAdded && (
                            <span className="text-xs bg-primary text-primary-foreground px-1.5 py-0.5 rounded font-bold">
                              STOP
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-muted-foreground truncate">
                          {isAdded ? `Exit in ${stop.distanceAhead} mi` : stop.amenities.slice(0, 3).join(" • ")}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-bold text-primary">{stop.distanceAhead} mi</p>
                        <p className="text-xs text-muted-foreground">{stop.timeAhead} min</p>
                      </div>
                    </button>
                  );
                })
              ) : (
                <div className="px-4 py-6 text-center text-muted-foreground text-sm">
                  No {activeFilter || ""} stops found in next {scanDistance} miles
                </div>
              )}
            </div>

            {upcomingStops.length > 4 && (
              <div className="px-4 py-2 text-center border-t border-border/50">
                <span className="text-xs text-muted-foreground">
                  +{upcomingStops.length - 4} more stops ahead
                </span>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Bottom Info Panel */}
      <div className="relative z-10 bg-background/95 backdrop-blur border-t border-border">
        {/* ETA and Distance */}
        <div className="grid grid-cols-3 divide-x divide-border p-4">
          <div className="text-center">
            <p className="text-2xl font-display font-bold text-foreground" data-testid="text-time-remaining">
              {hours}h {minutes}m
            </p>
            <p className="text-xs text-muted-foreground uppercase">Remaining</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-display font-bold text-foreground" data-testid="text-distance-remaining">
              {remainingDistance}
            </p>
            <p className="text-xs text-muted-foreground uppercase">Miles</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-display font-bold text-primary" data-testid="text-eta">
              {new Date(Date.now() + remainingMinutes * 60000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
            </p>
            <p className="text-xs text-muted-foreground uppercase">ETA</p>
          </div>
        </div>

        {/* Quick Actions - Tap to filter, tap again to extend scan */}
        <div className="flex flex-wrap justify-center gap-2 p-3 border-t border-border">
          <Button 
            variant={activeFilter === "fuel" ? "default" : "ghost"} 
            size="sm"
            onClick={() => handleFilterTap("fuel")}
            data-testid="button-fuel"
          >
            <Fuel className={`h-4 w-4 mr-1 ${activeFilter === "fuel" ? "" : "text-green-500"}`} />
            Fuel
          </Button>
          <Button 
            variant={activeFilter === "rest" ? "default" : "ghost"} 
            size="sm"
            onClick={() => handleFilterTap("rest")}
            data-testid="button-rest"
          >
            <Coffee className={`h-4 w-4 mr-1 ${activeFilter === "rest" ? "" : "text-amber-500"}`} />
            Rest
          </Button>
          <Button 
            variant={activeFilter === "bathroom" ? "default" : "ghost"} 
            size="sm"
            onClick={() => handleFilterTap("bathroom")}
            data-testid="button-bathroom"
          >
            <Bath className={`h-4 w-4 mr-1 ${activeFilter === "bathroom" ? "" : "text-blue-500"}`} />
            Bathroom
          </Button>
          <Button 
            variant={activeFilter === "parking" ? "default" : "ghost"} 
            size="sm"
            onClick={() => handleFilterTap("parking")}
            data-testid="button-parking"
          >
            <ParkingCircle className={`h-4 w-4 mr-1 ${activeFilter === "parking" ? "" : "text-purple-500"}`} />
            Parking
          </Button>
        </div>

        {/* Added Stops Summary */}
        {addedStops.length > 0 && (
          <div className="px-4 py-2 border-t border-border flex items-center justify-center gap-2">
            <MapPin className="h-3 w-3 text-primary" />
            <span className="text-xs font-bold text-primary">{addedStops.length} stop{addedStops.length > 1 ? 's' : ''} added to route</span>
          </div>
        )}

        {/* Destination Summary */}
        <div className="px-4 pb-4">
          <div className="bg-secondary rounded-lg p-3 flex items-center gap-3">
            <div className="bg-primary/20 rounded-full p-2">
              <MapPin className="h-4 w-4 text-primary" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-bold text-foreground truncate" data-testid="text-destination-address">
                {(trip.endLocation as any).address}
              </p>
              <p className="text-xs text-muted-foreground">Final Destination</p>
            </div>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </div>
        </div>
      </div>
    </div>
  );
}
