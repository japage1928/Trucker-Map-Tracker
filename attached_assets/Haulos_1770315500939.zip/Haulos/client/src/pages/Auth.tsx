import { Truck } from "lucide-react";
import truckHighwayImage from "../assets/images/truck-highway.jpg";

export default function AuthPage() {
  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-5xl grid lg:grid-cols-2 bg-secondary rounded-2xl overflow-hidden shadow-2xl border border-muted">
        
        {/* Left Side - Visual */}
        <div className="relative hidden lg:flex flex-col justify-between p-12 bg-black">
          {/* Semi truck highway photo */}
          <div className="absolute inset-0">
             <img 
              src={truckHighwayImage}
              className="w-full h-full object-cover opacity-50"
              alt="Semi truck on highway"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-black/50" />
          </div>

          <div className="relative z-10">
            <div className="flex items-center gap-3 mb-6">
              <Truck className="w-10 h-10 text-primary" />
              <h1 className="text-4xl font-display font-bold text-white tracking-tighter">
                HAUL<span className="text-primary">OS</span>
              </h1>
            </div>
            <p className="text-gray-300 text-lg max-w-md">
              The professional routing system for commercial drivers. Avoid low bridges, hazmat restrictions, and bad roads.
            </p>
          </div>

          <div className="relative z-10 text-xs text-gray-500 font-mono">
            V 2.0.4 | SYSTEM OPERATIONAL
          </div>
        </div>

        {/* Right Side - Login */}
        <div className="p-8 md:p-12 flex flex-col justify-center bg-secondary">
          <div className="text-center mb-8 lg:hidden">
            <Truck className="w-12 h-12 text-primary mx-auto mb-4" />
            <h1 className="text-3xl font-display font-bold text-white tracking-tighter">
                HAUL<span className="text-primary">OS</span>
            </h1>
          </div>

          <div className="space-y-6 max-w-sm mx-auto w-full">
            <div className="text-center space-y-2">
              <h2 className="text-2xl font-bold text-foreground">Welcome, Driver</h2>
              <p className="text-muted-foreground">Sign in or create an account to start planning your routes.</p>
            </div>

            {/* Returning User - Sign In */}
            <a 
              href="/api/login"
              data-testid="button-login"
              className="group relative flex items-center justify-center w-full py-4 px-6 bg-primary text-primary-foreground font-bold text-lg rounded-lg shadow-[0_0_20px_rgba(255,204,0,0.2)] hover:shadow-[0_0_30px_rgba(255,204,0,0.4)] hover:-translate-y-0.5 transition-all duration-200"
            >
              <span className="absolute inset-0 w-full h-full bg-white/20 group-hover:bg-white/30 rounded-lg transition-colors" />
              <span className="relative z-10 uppercase tracking-widest">Sign In</span>
            </a>

            <div className="relative py-2">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-muted"></div>
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-secondary px-2 text-muted-foreground">New to HaulOS?</span>
              </div>
            </div>

            {/* New User - Create Account */}
            <a 
              href="/api/login"
              data-testid="button-create-account"
              className="group relative flex items-center justify-center w-full py-4 px-6 bg-background border-2 border-primary text-primary font-bold text-lg rounded-lg hover:bg-primary/10 hover:-translate-y-0.5 transition-all duration-200"
            >
              <span className="relative z-10 uppercase tracking-widest">Create Account</span>
            </a>

            <p className="text-center text-xs text-muted-foreground">
              Both options use secure Replit authentication
            </p>

            <div className="relative py-2">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-muted"></div>
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-secondary px-2 text-muted-foreground">Professional Features</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 text-center text-xs text-muted-foreground font-mono">
              <div className="p-3 bg-background/50 rounded border border-muted">
                <span className="block text-primary font-bold text-lg mb-1">100%</span>
                TRUCK LEGAL
              </div>
              <div className="p-3 bg-background/50 rounded border border-muted">
                <span className="block text-primary font-bold text-lg mb-1">24/7</span>
                OFFLINE MODE
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
