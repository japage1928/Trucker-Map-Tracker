import { useVehicles, useDeleteVehicle } from "@/hooks/use-vehicles";
import { VehicleForm } from "@/components/VehicleForm";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Truck, Trash2, Edit, AlertTriangle } from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export default function VehiclesPage() {
  const { data: vehicles, isLoading } = useVehicles();
  const deleteMutation = useDeleteVehicle();

  if (isLoading) {
    return (
      <div className="p-8 text-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4" />
        <p className="text-muted-foreground">Loading fleet...</p>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8 max-w-7xl mx-auto space-y-8">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl md:text-4xl font-display font-bold text-foreground">VEHICLE PROFILES</h1>
          <p className="text-muted-foreground">Manage your fleet specs for accurate routing.</p>
        </div>
        <VehicleForm />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {vehicles?.map((vehicle) => (
          <Card key={vehicle.id} className="bg-secondary border-muted hover:border-primary/50 transition-colors group relative overflow-hidden">
            {/* Visual Header */}
            <div className="h-24 bg-gradient-to-r from-background to-secondary border-b border-muted relative flex items-center justify-center">
              <Truck className="h-12 w-12 text-muted-foreground/30 group-hover:text-primary transition-colors duration-300" />
              {vehicle.hazmat && (
                <div className="absolute top-2 right-2 bg-destructive text-white text-[10px] font-bold px-2 py-0.5 rounded flex items-center gap-1">
                  <AlertTriangle className="h-3 w-3" /> HAZMAT
                </div>
              )}
            </div>

            <CardContent className="pt-6">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="text-xl font-bold font-display text-foreground uppercase">{vehicle.name}</h3>
                  <p className="text-sm text-primary font-mono uppercase">{vehicle.type}</p>
                </div>
                
                <div className="flex gap-2">
                   <VehicleForm 
                     vehicle={vehicle} 
                     trigger={
                       <Button size="icon" variant="ghost" className="h-8 w-8 text-muted-foreground hover:text-white">
                         <Edit className="h-4 w-4" />
                       </Button>
                     }
                   />
                   
                   <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button size="icon" variant="ghost" className="h-8 w-8 text-muted-foreground hover:text-destructive">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent className="bg-secondary border-border text-foreground">
                      <AlertDialogHeader>
                        <AlertDialogTitle>Delete Vehicle?</AlertDialogTitle>
                        <AlertDialogDescription>
                          This will permanently remove {vehicle.name} from your fleet.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel className="bg-background border-muted hover:bg-background/80">Cancel</AlertDialogCancel>
                        <AlertDialogAction 
                          onClick={() => deleteMutation.mutate(vehicle.id)}
                          className="bg-destructive text-white hover:bg-destructive/90"
                        >
                          Delete
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                   </AlertDialog>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-px bg-muted/30 border border-muted/50 rounded-lg overflow-hidden">
                 <div className="bg-background/50 p-3">
                   <div className="text-[10px] text-muted-foreground uppercase font-bold">Height</div>
                   <div className="font-mono text-white">{vehicle.height}'</div>
                 </div>
                 <div className="bg-background/50 p-3">
                   <div className="text-[10px] text-muted-foreground uppercase font-bold">Weight</div>
                   <div className="font-mono text-white">{(vehicle.weight / 1000).toFixed(0)}k lbs</div>
                 </div>
                 <div className="bg-background/50 p-3">
                   <div className="text-[10px] text-muted-foreground uppercase font-bold">Length</div>
                   <div className="font-mono text-white">{vehicle.length}'</div>
                 </div>
                 <div className="bg-background/50 p-3">
                   <div className="text-[10px] text-muted-foreground uppercase font-bold">Width</div>
                   <div className="font-mono text-white">{vehicle.width}'</div>
                 </div>
              </div>
            </CardContent>
          </Card>
        ))}

        {/* Empty State */}
        {vehicles?.length === 0 && (
          <div className="col-span-full py-16 text-center border-2 border-dashed border-muted rounded-xl bg-background/30">
            <Truck className="h-16 w-16 mx-auto text-muted-foreground mb-4 opacity-50" />
            <h3 className="text-xl font-bold text-foreground">No Vehicles Added</h3>
            <p className="text-muted-foreground max-w-sm mx-auto mt-2 mb-6">
              Add your first truck profile to start planning safe routes.
            </p>
            <VehicleForm />
          </div>
        )}
      </div>
    </div>
  );
}
