import { useAuth } from "@/hooks/use-auth";
import { useVehicles } from "@/hooks/use-vehicles";
import { useTrips } from "@/hooks/use-trips";
import { Map } from "@/components/Map";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Truck, MapPin, Navigation, AlertTriangle, Plus } from "lucide-react";
import { Link } from "wouter";
import { Skeleton } from "@/components/ui/skeleton";

export default function Dashboard() {
  const { user } = useAuth();
  const { data: vehicles, isLoading: loadingVehicles } = useVehicles();
  const { data: trips, isLoading: loadingTrips } = useTrips();

  const activeVehicle = vehicles?.[0]; // Just picking first one for MVP
  const recentTrip = trips?.[0];

  return (
    <div className="p-4 md:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl md:text-4xl font-display font-bold text-foreground">
            DASHBOARD
          </h1>
          <p className="text-muted-foreground font-mono mt-1">
            DRIVER: <span className="text-primary font-bold">{user?.firstName} {user?.lastName}</span>
          </p>
        </div>
        <Link href="/trips">
          <Button className="bg-primary text-primary-foreground font-bold hover:bg-yellow-400 shadow-lg shadow-primary/20">
            <Plus className="mr-2 h-5 w-5" /> NEW TRIP PLAN
          </Button>
        </Link>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Main Status Panel */}
        <div className="lg:col-span-2 space-y-6">
          {/* Active Trip Card */}
          <Card className="bg-secondary border-muted shadow-lg overflow-hidden relative group">
            <div className="absolute top-0 left-0 w-1 h-full bg-primary" />
            <CardHeader className="pb-2">
              <div className="flex justify-between items-center">
                <CardTitle className="text-xl font-display text-white flex items-center gap-2">
                  <Navigation className="h-5 w-5 text-primary" /> CURRENT ROUTE
                </CardTitle>
                <span className="px-2 py-1 bg-green-500/10 text-green-500 text-xs font-bold border border-green-500/20 rounded">
                  ACTIVE
                </span>
              </div>
            </CardHeader>
            <CardContent>
              {loadingTrips ? (
                <Skeleton className="h-32 w-full bg-background/50" />
              ) : recentTrip ? (
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-4">
                    <div>
                      <label className="text-xs text-muted-foreground font-mono uppercase">Origin</label>
                      <p className="text-lg font-bold text-white truncate">{(recentTrip.startLocation as any).address}</p>
                    </div>
                    <div className="border-l-2 border-dashed border-muted pl-4 ml-1">
                      <div className="h-8" />
                    </div>
                    <div>
                      <label className="text-xs text-muted-foreground font-mono uppercase">Destination</label>
                      <p className="text-lg font-bold text-white truncate">{(recentTrip.endLocation as any).address}</p>
                    </div>
                  </div>
                  <div className="bg-background rounded-lg p-4 flex flex-col justify-center space-y-2 border border-muted">
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground text-sm">Distance</span>
                      <span className="font-mono font-bold text-white">{recentTrip.distance} mi</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground text-sm">Est. Time</span>
                      <span className="font-mono font-bold text-white text-xl">
                        {Math.floor(recentTrip.duration! / 60)}h {recentTrip.duration! % 60}m
                      </span>
                    </div>
                    <Link href={`/navigate/${recentTrip.id}`}>
                      <Button className="w-full mt-2" variant="outline" data-testid="button-resume-navigation">
                        Resume Navigation
                      </Button>
                    </Link>
                  </div>
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-8 text-muted-foreground">
                  <MapPin className="h-12 w-12 mb-3 opacity-20" />
                  <p>No active trips found.</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Map Preview */}
          <div className="h-[300px] md:h-[400px] rounded-xl overflow-hidden border border-muted shadow-lg">
             {/* Pass recent trip coordinates if available, else default */}
            <Map center={recentTrip ? [(recentTrip.startLocation as any).lat, (recentTrip.startLocation as any).lng] : undefined} />
          </div>
        </div>

        {/* Side Panel - Vehicle & Stats */}
        <div className="space-y-6">
          {/* Active Vehicle */}
          <Card className="bg-secondary border-muted shadow-lg relative">
             <div className="absolute top-0 right-0 p-4 opacity-5 pointer-events-none">
               <Truck className="w-32 h-32" />
             </div>
            <CardHeader>
              <CardTitle className="text-xl font-display text-white flex items-center gap-2">
                <Truck className="h-5 w-5 text-primary" /> ACTIVE RIG
              </CardTitle>
            </CardHeader>
            <CardContent>
              {loadingVehicles ? (
                <div className="space-y-2">
                  <Skeleton className="h-8 w-full bg-background/50" />
                  <Skeleton className="h-8 w-full bg-background/50" />
                </div>
              ) : activeVehicle ? (
                <div className="space-y-4">
                  <div>
                    <h3 className="text-2xl font-bold text-white">{activeVehicle.name}</h3>
                    <p className="text-primary font-mono text-sm uppercase">{activeVehicle.type}</p>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div className="bg-background p-2 rounded border border-muted">
                      <span className="block text-muted-foreground text-xs uppercase">Height</span>
                      <span className="font-mono font-bold text-white">{activeVehicle.height} ft</span>
                    </div>
                    <div className="bg-background p-2 rounded border border-muted">
                      <span className="block text-muted-foreground text-xs uppercase">Weight</span>
                      <span className="font-mono font-bold text-white">{activeVehicle.weight.toLocaleString()} lbs</span>
                    </div>
                    <div className="bg-background p-2 rounded border border-muted">
                      <span className="block text-muted-foreground text-xs uppercase">Length</span>
                      <span className="font-mono font-bold text-white">{activeVehicle.length} ft</span>
                    </div>
                    <div className="bg-background p-2 rounded border border-muted">
                      <span className="block text-muted-foreground text-xs uppercase">Axles</span>
                      <span className="font-mono font-bold text-white">{activeVehicle.axleCount}</span>
                    </div>
                  </div>
                  
                  {activeVehicle.hazmat && (
                    <div className="flex items-center gap-2 text-destructive bg-destructive/10 p-2 rounded border border-destructive/20">
                      <AlertTriangle className="h-4 w-4" />
                      <span className="font-bold text-xs">HAZMAT LOADED</span>
                    </div>
                  )}

                  <Link href="/vehicles">
                    <Button variant="outline" className="w-full mt-2 border-primary/20 hover:bg-primary/10 hover:text-primary">
                      Switch Vehicle
                    </Button>
                  </Link>
                </div>
              ) : (
                <div className="text-center py-6">
                  <p className="text-muted-foreground mb-4">No vehicles configured.</p>
                  <Link href="/vehicles">
                    <Button>Add Vehicle</Button>
                  </Link>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Quick Stats */}
          <div className="grid grid-cols-2 gap-4">
             <div className="bg-secondary border border-muted rounded-xl p-4 flex flex-col items-center justify-center text-center">
                <span className="text-3xl font-display font-bold text-white">1,240</span>
                <span className="text-xs text-muted-foreground uppercase mt-1">Miles this week</span>
             </div>
             <div className="bg-secondary border border-muted rounded-xl p-4 flex flex-col items-center justify-center text-center">
                <span className="text-3xl font-display font-bold text-white">42</span>
                <span className="text-xs text-muted-foreground uppercase mt-1">Hours Driving</span>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
}
