import { Link, Redirect } from "wouter";
import { Truck, Loader2 } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";

export default function NotFound() {
  const { user, isLoading } = useAuth();

  // Show loading while checking auth
  if (isLoading) {
    return (
      <div className="min-h-screen w-full flex items-center justify-center bg-background">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  // If not logged in, redirect to auth page instead of showing 404
  if (!user) {
    return <Redirect to="/auth" />;
  }

  // Show 404 only for authenticated users who hit a bad route
  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-background p-4">
      <div className="max-w-md w-full text-center space-y-6">
        <div className="flex justify-center">
          <div className="relative">
            <Truck className="h-24 w-24 text-primary" />
            <div className="absolute inset-0 blur-xl bg-primary/20 rounded-full" />
          </div>
        </div>
        
        <h1 className="text-6xl font-display font-bold text-foreground tracking-tighter">404</h1>
        
        <div className="space-y-2">
          <h2 className="text-xl font-bold text-foreground uppercase">Route Not Found</h2>
          <p className="text-muted-foreground">
            The coordinates you are looking for do not exist on our map. You might have taken a wrong turn.
          </p>
        </div>

        <Link href="/" className="inline-block w-full">
           <button className="w-full py-4 bg-primary text-primary-foreground font-bold rounded-lg hover:bg-primary/90 transition-all uppercase tracking-widest">
             Return to Dashboard
           </button>
        </Link>
      </div>
    </div>
  );
}
