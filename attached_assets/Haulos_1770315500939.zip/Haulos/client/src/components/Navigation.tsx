import { Link, useLocation } from "wouter";
import { Truck, Map, Settings, LogOut, Home } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { cn } from "@/lib/utils";

export function Navigation() {
  const [location] = useLocation();
  const { logout } = useAuth();

  const navItems = [
    { href: "/", icon: Home, label: "Dashboard" },
    { href: "/trips", icon: Map, label: "Trips" },
    { href: "/vehicles", icon: Truck, label: "Vehicles" },
  ];

  return (
    <nav className="fixed bottom-0 left-0 w-full z-50 md:relative md:w-64 md:h-screen bg-background border-t md:border-t-0 md:border-r border-border md:flex md:flex-col">
      <div className="hidden md:flex items-center p-6 border-b border-border">
        <Truck className="h-8 w-8 text-primary mr-3" />
        <span className="font-display text-2xl font-bold tracking-tighter text-foreground">
          HAUL<span className="text-primary">OS</span>
        </span>
      </div>

      <div className="flex flex-row md:flex-col justify-around md:justify-start flex-1 p-2 md:p-4 gap-1 md:gap-2">
        {navItems.map((item) => {
          const isActive = location === item.href;
          return (
            <Link key={item.href} href={item.href} className={cn(
              "flex flex-col md:flex-row items-center justify-center md:justify-start p-3 md:px-4 md:py-3 rounded-lg transition-all duration-200 group",
              isActive 
                ? "bg-primary text-primary-foreground shadow-[0_0_15px_rgba(255,204,0,0.3)]" 
                : "text-muted-foreground hover:bg-secondary hover:text-foreground"
            )}>
              <item.icon className={cn(
                "h-6 w-6 md:mr-3 mb-1 md:mb-0 transition-transform duration-200",
                isActive ? "scale-110" : "group-hover:scale-110"
              )} />
              <span className="text-xs md:text-base font-medium uppercase tracking-wide">{item.label}</span>
            </Link>
          );
        })}
      </div>

      <div className="hidden md:block p-4 border-t border-border">
        <button 
          onClick={() => logout()}
          className="flex items-center w-full px-4 py-3 text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded-lg transition-colors"
        >
          <LogOut className="h-5 w-5 mr-3" />
          <span className="font-medium uppercase tracking-wide">Log Out</span>
        </button>
      </div>
    </nav>
  );
}
