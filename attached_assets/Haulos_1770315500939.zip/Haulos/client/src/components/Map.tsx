import { MapContainer, TileLayer, Marker, Popup, Polyline } from 'react-leaflet';
import { type LatLngExpression, Icon } from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { type Poi } from "@shared/schema";
import markerIconPng from "leaflet/dist/images/marker-icon.png";
import markerIcon2xPng from "leaflet/dist/images/marker-icon-2x.png";
import markerShadowPng from "leaflet/dist/images/marker-shadow.png";

// Fix for default markers in react-leaflet not showing up
const defaultIcon = new Icon({
  iconUrl: markerIconPng,
  iconRetinaUrl: markerIcon2xPng,
  shadowUrl: markerShadowPng,
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

// Custom Icon for Trucks
const truckIcon = new Icon({
  iconUrl: "https://unpkg.com/leaflet-extra-markers@1.2.1/dist/img/markers/purple.png", // Using a placeholder for demo
  shadowUrl: markerShadowPng,
  iconSize: [35, 45],
  iconAnchor: [17, 42],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

interface MapProps {
  center?: [number, number];
  zoom?: number;
  route?: [number, number][]; // Array of lat,lng points for a polyline
  pois?: Poi[];
  startPoint?: [number, number];
  endPoint?: [number, number];
}

export function Map({ center = [39.8283, -98.5795], zoom = 4, route, pois, startPoint, endPoint }: MapProps) {
  return (
    <div className="w-full h-full min-h-[400px] rounded-lg overflow-hidden border border-muted shadow-2xl bg-black">
      <MapContainer 
        center={center as LatLngExpression} 
        zoom={zoom} 
        scrollWheelZoom={true} 
        className="w-full h-full"
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          className="filter brightness-[0.8] contrast-[1.2] hue-rotate-180 invert" // Dark mode map hack
        />
        
        {/* Render POIs */}
        {pois?.map((poi) => {
          const location = poi.location as { lat: number, lng: number };
          return (
            <Marker 
              key={poi.id} 
              position={[location.lat, location.lng]} 
              icon={defaultIcon}
            >
              <Popup>
                <div className="font-sans text-sm">
                  <h3 className="font-bold">{poi.name}</h3>
                  <p className="capitalize text-gray-600">{poi.type.replace('_', ' ')}</p>
                </div>
              </Popup>
            </Marker>
          );
        })}

        {/* Render Route Polyline */}
        {route && route.length > 0 && (
          <Polyline 
            positions={route as LatLngExpression[]} 
            pathOptions={{ color: '#FFCC00', weight: 5, opacity: 0.8 }} 
          />
        )}

        {/* Start Point */}
        {startPoint && (
          <Marker position={startPoint as LatLngExpression} icon={truckIcon}>
            <Popup>Start Location</Popup>
          </Marker>
        )}

        {/* End Point */}
        {endPoint && (
          <Marker position={endPoint as LatLngExpression} icon={defaultIcon}>
            <Popup>Destination</Popup>
          </Marker>
        )}
      </MapContainer>
    </div>
  );
}
