import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertVehicleSchema, type InsertVehicle } from "@shared/schema";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useCreateVehicle, useUpdateVehicle } from "@/hooks/use-vehicles";
import { useState } from "react";
import { Loader2 } from "lucide-react";

interface VehicleFormProps {
  vehicle?: InsertVehicle & { id: number }; // Existing vehicle for edit mode
  trigger?: React.ReactNode;
}

export function VehicleForm({ vehicle, trigger }: VehicleFormProps) {
  const [open, setOpen] = useState(false);
  const createMutation = useCreateVehicle();
  const updateMutation = useUpdateVehicle();
  const isEditing = !!vehicle;

  const form = useForm<InsertVehicle>({
    resolver: zodResolver(insertVehicleSchema),
    defaultValues: vehicle || {
      name: "",
      type: "semi",
      height: 13.5, // Standard height in feet
      weight: 80000, // Max loaded weight
      length: 53, // Standard trailer length
      width: 8.5,
      axleCount: 5,
      hazmat: false,
    },
  });

  const onSubmit = async (data: InsertVehicle) => {
    try {
      if (isEditing) {
        await updateMutation.mutateAsync({ id: vehicle.id, ...data });
      } else {
        await createMutation.mutateAsync(data);
      }
      setOpen(false);
      form.reset();
    } catch (error) {
      console.error(error);
    }
  };

  const isPending = createMutation.isPending || updateMutation.isPending;

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger || <Button>Add Vehicle</Button>}
      </DialogTrigger>
      <DialogContent className="sm:max-w-[500px] bg-secondary border-border text-foreground">
        <DialogHeader>
          <DialogTitle className="text-2xl font-display text-primary">
            {isEditing ? "EDIT VEHICLE PROFILE" : "ADD NEW VEHICLE"}
          </DialogTitle>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6 mt-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Vehicle Nickname</FormLabel>
                  <FormControl>
                    <Input {...field} placeholder="e.g. Big Red" className="bg-background border-muted focus:border-primary" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="type"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Truck Type</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger className="bg-background border-muted">
                          <SelectValue placeholder="Select type" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="semi">Semi-Trailer</SelectItem>
                        <SelectItem value="box">Box Truck</SelectItem>
                        <SelectItem value="flatbed">Flatbed</SelectItem>
                        <SelectItem value="hotshot">Hotshot</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="axleCount"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Axles</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        {...field} 
                        onChange={e => field.onChange(parseInt(e.target.value))}
                        className="bg-background border-muted" 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="height"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Height (ft)</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        step="0.1" 
                        {...field} 
                        onChange={e => field.onChange(parseFloat(e.target.value))}
                        className="bg-background border-muted font-mono" 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="weight"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Weight (lbs)</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        {...field} 
                        onChange={e => field.onChange(parseInt(e.target.value))}
                        className="bg-background border-muted font-mono" 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="length"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Length (ft)</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        step="0.1"
                        {...field} 
                        onChange={e => field.onChange(parseFloat(e.target.value))}
                        className="bg-background border-muted font-mono" 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
               <FormField
                control={form.control}
                name="width"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Width (ft)</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        step="0.1"
                        {...field} 
                        onChange={e => field.onChange(parseFloat(e.target.value))}
                        className="bg-background border-muted font-mono" 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <Button 
              type="submit" 
              className="w-full h-12 text-lg font-bold bg-primary text-primary-foreground hover:bg-yellow-400"
              disabled={isPending}
            >
              {isPending && <Loader2 className="mr-2 h-5 w-5 animate-spin" />}
              {isEditing ? "SAVE CHANGES" : "CREATE PROFILE"}
            </Button>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
