import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useSettings, useUpdateSettings, useDeleteAccount } from "@/hooks/use-settings";
import { useTheme } from "@/components/ThemeProvider";
import { queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Menu,
  User,
  LogOut,
  Trash2,
  Sun,
  Moon,
  Monitor,
  Gauge,
  Clock,
  ExternalLink,
  Shield,
  FileText,
  Loader2,
} from "lucide-react";
import { useLocation } from "wouter";

const APP_VERSION = "1.0.0";

export function HamburgerMenu() {
  const { user } = useAuth();
  const { data: settings, isLoading: settingsLoading } = useSettings();
  const updateSettings = useUpdateSettings();
  const deleteAccount = useDeleteAccount();
  const { theme, setTheme } = useTheme();
  const [, navigate] = useLocation();
  const [isOpen, setIsOpen] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  const handleLogout = () => {
    // Clear all cached queries before logout to ensure clean state
    queryClient.clear();
    window.location.href = "/api/logout";
  };

  const handleDeleteAccount = async () => {
    setIsDeleting(true);
    try {
      await deleteAccount.mutateAsync();
      window.location.href = "/auth";
    } catch (err) {
      console.error("Failed to delete account:", err);
      setIsDeleting(false);
    }
  };

  const handleThemeChange = (newTheme: "light" | "dark" | "system") => {
    setTheme(newTheme);
    updateSettings.mutate({ theme: newTheme });
  };

  const formatDuration = (minutes: number | null) => {
    if (!minutes || minutes === 0) return "0h";
    const hrs = Math.floor(minutes / 60);
    const mins = minutes % 60;
    if (hrs === 0) return `${mins}m`;
    if (mins === 0) return `${hrs}h`;
    return `${hrs}h ${mins}m`;
  };

  const formatMiles = (miles: number | null) => {
    if (!miles || miles === 0) return "0";
    return miles.toLocaleString();
  };

  if (!user) return null;

  return (
    <>
      <Sheet open={isOpen} onOpenChange={setIsOpen}>
        <SheetTrigger asChild>
          <Button 
            variant="ghost" 
            size="icon" 
            className="min-h-12 min-w-12"
            data-testid="button-hamburger-menu"
          >
            <Menu className="h-6 w-6" />
          </Button>
        </SheetTrigger>
        <SheetContent side="left" className="w-80 p-0 flex flex-col">
          <SheetHeader className="p-6 pb-4">
            <SheetTitle className="text-left flex items-center gap-2">
              <div className="bg-primary rounded-lg p-2">
                <User className="h-5 w-5 text-primary-foreground" />
              </div>
              <span>Menu</span>
            </SheetTitle>
          </SheetHeader>

          <div className="flex-1 overflow-y-auto">
            {/* Account Section */}
            <div className="px-6 py-4">
              <h3 className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-3">
                Account
              </h3>
              <div className="bg-secondary rounded-lg p-4 mb-4">
                <div className="flex items-center gap-3">
                  <div className="bg-primary/20 rounded-full p-2">
                    <User className="h-5 w-5 text-primary" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-bold text-foreground truncate" data-testid="text-user-name">
                      {user.firstName} {user.lastName}
                    </p>
                    <p className="text-xs text-muted-foreground truncate" data-testid="text-user-email">
                      {user.email || "Signed in with Google"}
                    </p>
                  </div>
                </div>
              </div>

              <div className="flex flex-col gap-2">
                <Button
                  variant="outline"
                  className="w-full justify-start min-h-12"
                  onClick={handleLogout}
                  data-testid="button-logout"
                >
                  <LogOut className="h-5 w-5 mr-3" />
                  Log Out
                </Button>
                <Button
                  variant="ghost"
                  className="w-full justify-start min-h-12 text-destructive hover:text-destructive"
                  onClick={() => setShowDeleteConfirm(true)}
                  data-testid="button-delete-account"
                >
                  <Trash2 className="h-5 w-5 mr-3" />
                  Delete Account
                </Button>
              </div>
            </div>

            <Separator />

            {/* Driver Metrics Section */}
            <div className="px-6 py-4">
              <h3 className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-3">
                Driver Metrics
              </h3>
              {settingsLoading ? (
                <div className="flex items-center justify-center py-4">
                  <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
                </div>
              ) : (
                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-secondary rounded-lg p-4 text-center">
                    <Gauge className="h-6 w-6 text-primary mx-auto mb-2" />
                    <p className="text-xl font-display font-bold text-foreground" data-testid="text-total-miles">
                      {formatMiles(settings?.totalMilesDriven ?? 0)}
                    </p>
                    <p className="text-xs text-muted-foreground">Miles Driven</p>
                  </div>
                  <div className="bg-secondary rounded-lg p-4 text-center">
                    <Clock className="h-6 w-6 text-accent mx-auto mb-2" />
                    <p className="text-xl font-display font-bold text-foreground" data-testid="text-total-time">
                      {formatDuration(settings?.totalTimeDriven ?? 0)}
                    </p>
                    <p className="text-xs text-muted-foreground">Time Driven</p>
                  </div>
                </div>
              )}
            </div>

            <Separator />

            {/* Settings Section */}
            <div className="px-6 py-4">
              <h3 className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-3">
                Settings
              </h3>
              <div className="space-y-2">
                <p className="text-sm font-medium text-foreground mb-2">Theme</p>
                <div className="flex flex-wrap gap-2">
                  <Button
                    variant={theme === "light" ? "default" : "outline"}
                    size="sm"
                    onClick={() => handleThemeChange("light")}
                    data-testid="button-theme-light"
                  >
                    <Sun className="h-4 w-4 mr-2" />
                    Light
                  </Button>
                  <Button
                    variant={theme === "dark" ? "default" : "outline"}
                    size="sm"
                    onClick={() => handleThemeChange("dark")}
                    data-testid="button-theme-dark"
                  >
                    <Moon className="h-4 w-4 mr-2" />
                    Dark
                  </Button>
                  <Button
                    variant={theme === "system" ? "default" : "outline"}
                    size="sm"
                    onClick={() => handleThemeChange("system")}
                    data-testid="button-theme-system"
                  >
                    <Monitor className="h-4 w-4 mr-2" />
                    System
                  </Button>
                </div>
              </div>
            </div>
          </div>

          {/* Footer */}
          <div className="border-t border-border p-4 bg-secondary/50">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs text-muted-foreground">HaulOS v{APP_VERSION}</span>
            </div>
            <div className="flex flex-wrap gap-3">
              <a
                href="/privacy"
                className="text-xs text-muted-foreground hover:text-foreground flex items-center gap-1"
                data-testid="link-privacy"
              >
                <Shield className="h-3 w-3" />
                Privacy Policy
              </a>
              <a
                href="/terms"
                className="text-xs text-muted-foreground hover:text-foreground flex items-center gap-1"
                data-testid="link-terms"
              >
                <FileText className="h-3 w-3" />
                Terms of Service
              </a>
            </div>
          </div>
        </SheetContent>
      </Sheet>

      {/* Delete Account Confirmation */}
      <AlertDialog open={showDeleteConfirm} onOpenChange={setShowDeleteConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Your Account?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete your account, 
              all your vehicles, trips, and settings from our servers.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isDeleting} data-testid="button-cancel-delete">
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteAccount}
              disabled={isDeleting}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              data-testid="button-confirm-delete"
            >
              {isDeleting ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Deleting...
                </>
              ) : (
                "Delete Account"
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
