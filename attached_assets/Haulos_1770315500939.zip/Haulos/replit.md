# HaulOS - Commercial Truck Navigation System

## Overview

HaulOS is a purpose-built navigation and route planning application for commercial truck drivers. The system provides routing based on vehicle specifications including height, weight, length, and hazmat status. Drivers can manage vehicle profiles, plan trips with commercial-vehicle-appropriate routing, and navigate with awareness of truck-specific points of interest like truck stops, rest areas, weigh stations, and parking facilities.

The application follows a full-stack TypeScript architecture with a React frontend, Express backend, and PostgreSQL database.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack React Query for server state caching and synchronization
- **UI Components**: shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with custom industrial dark theme (safety yellow primary, industrial grays)
- **Forms**: React Hook Form with Zod validation
- **Maps**: Leaflet with react-leaflet for interactive mapping

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **API Design**: RESTful endpoints defined in `shared/routes.ts` with Zod schemas for validation
- **Authentication**: Replit Auth integration using OpenID Connect with Passport.js
- **Session Management**: PostgreSQL-backed sessions via connect-pg-simple

### Data Layer
- **Database**: PostgreSQL
- **ORM**: Drizzle ORM with drizzle-zod for schema-to-validation integration
- **Schema Location**: `shared/schema.ts` contains all table definitions
- **Migrations**: Drizzle Kit for schema migrations (`db:push` command)

### Key Data Models
- **Users**: Authentication-managed user accounts (Replit Auth integration)
- **Vehicles**: Commercial vehicle profiles with dimensions (height, weight, length, width), axle count, and hazmat certification
- **Trips**: Route plans linking users to vehicles with start/end locations, waypoints, and status tracking
- **POIs**: Truck-specific points of interest (truck stops, rest areas, weigh stations, parking)

### Build System
- **Development**: Vite dev server with HMR, proxied through Express
- **Production**: Vite builds client to `dist/public`, esbuild bundles server to `dist/index.cjs`
- **Scripts**: 
  - `npm run dev` - Development mode
  - `npm run build` - Production build
  - `npm run db:push` - Push schema changes to database

### Project Structure
```
client/           # React frontend
  src/
    components/   # Reusable UI components
    hooks/        # Custom React hooks for data fetching
    pages/        # Route page components
    lib/          # Utilities and query client
server/           # Express backend
  replit_integrations/auth/  # Replit Auth implementation
shared/           # Shared code between client/server
  schema.ts       # Drizzle database schema
  routes.ts       # API route definitions with Zod schemas
  models/         # Shared type definitions
```

## External Dependencies

### Database
- **PostgreSQL**: Primary data store, connection via `DATABASE_URL` environment variable

### Authentication
- **Replit Auth**: OpenID Connect integration for user authentication
- **Session Secret**: `SESSION_SECRET` environment variable required

### Mapping & Routing
- **OpenStreetMap**: Tile provider for Leaflet maps (free, no API key required)
- **Photon Geocoder**: Address-to-coordinates lookup via Komoot's OSM-based geocoding API (prioritizes city/town results)
- **OSRM**: Open Source Routing Machine for real road-based route distance and duration calculation
- **Note**: Uses OSRM car profile with 10% time buffer for truck approximation; production would benefit from commercial truck routing API (HERE, TomTom, or Mapbox with truck profile)

### Predictive Navigation
- **Route Ahead Panel**: Collapsible panel showing upcoming truck stops along the route
  - Default scan distance: 30 miles ahead
  - Shows POIs with name, amenities, distance, and estimated time
  - All results filtered for truck accessibility
- **Quick-Tap Filters**: Fuel, Rest, Bathroom, Parking buttons
  - Single tap: Filter to that type + extend scan to 50 miles
  - Repeated tap: Extend scan further (+30 miles each, max 200 miles)
  - Clear button resets filter and scan distance
- **Design Philosophy**: Non-intrusive, driver can see what's ahead without searching, enables calm decisions made early
- **Note**: Currently uses simulated POI data; production would integrate with real truck stop APIs (Trucker Path, RoadTrippers, etc.)

### UI Dependencies
- **Radix UI**: Headless component primitives
- **Lucide React**: Icon library
- **Tailwind CSS**: Utility-first CSS framework

### Key NPM Packages
- `drizzle-orm` / `drizzle-kit`: Database ORM and migration tooling
- `@tanstack/react-query`: Server state management
- `react-hook-form`: Form state management
- `zod`: Schema validation (shared between client and server)
- `leaflet` / `react-leaflet`: Interactive mapping
- `passport` / `openid-client`: Authentication