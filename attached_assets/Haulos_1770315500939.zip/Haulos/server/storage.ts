import { db } from "./db";
import {
  vehicles, trips, pois, userSettings,
  type Vehicle, type InsertVehicle,
  type Trip, type InsertTrip,
  type Poi, type InsertPoi,
  type UserSettings
} from "@shared/schema";
import { eq, and } from "drizzle-orm";
import { authStorage } from "./replit_integrations/auth/storage";

export * from "./replit_integrations/auth/storage";

export interface IStorage {
  // Vehicles
  getVehicles(userId: string): Promise<Vehicle[]>;
  getVehicle(id: number): Promise<Vehicle | undefined>;
  createVehicle(vehicle: InsertVehicle & { userId: string }): Promise<Vehicle>;
  updateVehicle(id: number, vehicle: Partial<InsertVehicle>): Promise<Vehicle>;
  deleteVehicle(id: number): Promise<void>;

  // Trips
  getTrips(userId: string): Promise<Trip[]>;
  getTrip(id: number): Promise<Trip | undefined>;
  createTrip(trip: InsertTrip & { userId: string }): Promise<Trip>;
  updateTrip(id: number, trip: Partial<InsertTrip>): Promise<Trip>;
  deleteTrip(id: number): Promise<void>;

  // POIs
  getPois(filters?: { lat?: number; lng?: number; radius?: number; type?: string }): Promise<Poi[]>;
  createPoi(poi: InsertPoi): Promise<Poi>;

  // User Settings
  getUserSettings(userId: string): Promise<UserSettings | undefined>;
  upsertUserSettings(userId: string, settings: Partial<UserSettings>): Promise<UserSettings>;
  deleteUserData(userId: string): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  // Vehicles
  async getVehicles(userId: string): Promise<Vehicle[]> {
    return await db.select().from(vehicles).where(eq(vehicles.userId, userId));
  }

  async getVehicle(id: number): Promise<Vehicle | undefined> {
    const [vehicle] = await db.select().from(vehicles).where(eq(vehicles.id, id));
    return vehicle;
  }

  async createVehicle(insertVehicle: InsertVehicle & { userId: string }): Promise<Vehicle> {
    const [vehicle] = await db.insert(vehicles).values(insertVehicle).returning();
    return vehicle;
  }

  async updateVehicle(id: number, updates: Partial<InsertVehicle>): Promise<Vehicle> {
    const [updated] = await db
      .update(vehicles)
      .set(updates)
      .where(eq(vehicles.id, id))
      .returning();
    return updated;
  }

  async deleteVehicle(id: number): Promise<void> {
    await db.delete(vehicles).where(eq(vehicles.id, id));
  }

  // Trips
  async getTrips(userId: string): Promise<Trip[]> {
    return await db.select().from(trips).where(eq(trips.userId, userId));
  }

  async getTrip(id: number): Promise<Trip | undefined> {
    const [trip] = await db.select().from(trips).where(eq(trips.id, id));
    return trip;
  }

  async createTrip(insertTrip: InsertTrip & { userId: string }): Promise<Trip> {
    const [trip] = await db.insert(trips).values(insertTrip).returning();
    return trip;
  }

  async updateTrip(id: number, updates: Partial<InsertTrip>): Promise<Trip> {
    const [updated] = await db
      .update(trips)
      .set(updates)
      .where(eq(trips.id, id))
      .returning();
    return updated;
  }

  async deleteTrip(id: number): Promise<void> {
    await db.delete(trips).where(eq(trips.id, id));
  }

  // POIs
  async getPois(filters?: { lat?: number; lng?: number; radius?: number; type?: string }): Promise<Poi[]> {
    let query = db.select().from(pois);

    if (filters?.type) {
      // @ts-ignore
      query = query.where(eq(pois.type, filters.type));
    }

    // Geo-filtering would ideally use PostGIS, but for MVP we'll just return all or filter in memory if small
    // Or basic lat/lng box if we implement it. For now, returning all for MVP simplicity.
    return await query;
  }

  async createPoi(insertPoi: InsertPoi): Promise<Poi> {
    const [poi] = await db.insert(pois).values(insertPoi).returning();
    return poi;
  }

  // User Settings
  async getUserSettings(userId: string): Promise<UserSettings | undefined> {
    const [settings] = await db.select().from(userSettings).where(eq(userSettings.userId, userId));
    return settings;
  }

  async upsertUserSettings(userId: string, updates: Partial<UserSettings>): Promise<UserSettings> {
    const existing = await this.getUserSettings(userId);
    if (existing) {
      const [updated] = await db
        .update(userSettings)
        .set({ ...updates, updatedAt: new Date() })
        .where(eq(userSettings.userId, userId))
        .returning();
      return updated;
    } else {
      const [created] = await db
        .insert(userSettings)
        .values({ userId, ...updates })
        .returning();
      return created;
    }
  }

  async deleteUserData(userId: string): Promise<void> {
    await db.delete(trips).where(eq(trips.userId, userId));
    await db.delete(vehicles).where(eq(vehicles.userId, userId));
    await db.delete(userSettings).where(eq(userSettings.userId, userId));
  }
}

export const storage = new DatabaseStorage();
