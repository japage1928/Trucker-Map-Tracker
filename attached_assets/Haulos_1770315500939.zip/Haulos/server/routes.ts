import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { setupAuth, registerAuthRoutes, isAuthenticated } from "./replit_integrations/auth";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  // Setup Auth
  await setupAuth(app);
  registerAuthRoutes(app);

  // Vehicles
  app.get(api.vehicles.list.path, isAuthenticated, async (req: any, res) => {
    const userId = req.user.claims.sub;
    const vehicles = await storage.getVehicles(userId);
    res.json(vehicles);
  });

  app.post(api.vehicles.create.path, isAuthenticated, async (req: any, res) => {
    try {
      const input = api.vehicles.create.input.parse(req.body);
      const userId = req.user.claims.sub;
      const vehicle = await storage.createVehicle({ ...input, userId });
      res.status(201).json(vehicle);
    } catch (err) {
      if (err instanceof z.ZodError) {
        res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      } else {
        res.status(500).json({ message: "Internal server error" });
      }
    }
  });

  app.get(api.vehicles.get.path, isAuthenticated, async (req: any, res) => {
    const vehicle = await storage.getVehicle(Number(req.params.id));
    if (!vehicle || vehicle.userId !== req.user.claims.sub) {
      return res.status(404).json({ message: 'Vehicle not found' });
    }
    res.json(vehicle);
  });

  app.put(api.vehicles.update.path, isAuthenticated, async (req: any, res) => {
    try {
      const existing = await storage.getVehicle(Number(req.params.id));
      if (!existing || existing.userId !== req.user.claims.sub) {
        return res.status(404).json({ message: 'Vehicle not found' });
      }

      const input = api.vehicles.update.input.parse(req.body);
      const updated = await storage.updateVehicle(Number(req.params.id), input);
      res.json(updated);
    } catch (err) {
      if (err instanceof z.ZodError) {
        res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
    }
  });

  app.delete(api.vehicles.delete.path, isAuthenticated, async (req: any, res) => {
    const existing = await storage.getVehicle(Number(req.params.id));
    if (!existing || existing.userId !== req.user.claims.sub) {
      return res.status(404).json({ message: 'Vehicle not found' });
    }
    await storage.deleteVehicle(Number(req.params.id));
    res.status(204).send();
  });

  // Trips
  app.get(api.trips.list.path, isAuthenticated, async (req: any, res) => {
    const userId = req.user.claims.sub;
    const trips = await storage.getTrips(userId);
    res.json(trips);
  });

  app.post(api.trips.create.path, isAuthenticated, async (req: any, res) => {
    try {
      const input = api.trips.create.input.parse(req.body);
      const userId = req.user.claims.sub;
      const trip = await storage.createTrip({ ...input, userId });
      res.status(201).json(trip);
    } catch (err) {
      if (err instanceof z.ZodError) {
        res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
    }
  });

  app.get(api.trips.get.path, isAuthenticated, async (req: any, res) => {
    const trip = await storage.getTrip(Number(req.params.id));
    if (!trip || trip.userId !== req.user.claims.sub) {
      return res.status(404).json({ message: 'Trip not found' });
    }
    res.json(trip);
  });

  app.put(api.trips.update.path, isAuthenticated, async (req: any, res) => {
    try {
      const existing = await storage.getTrip(Number(req.params.id));
      if (!existing || existing.userId !== req.user.claims.sub) {
        return res.status(404).json({ message: 'Trip not found' });
      }

      const input = api.trips.update.input.parse(req.body);
      const updated = await storage.updateTrip(Number(req.params.id), input);
      res.json(updated);
    } catch (err) {
      if (err instanceof z.ZodError) {
        res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
    }
  });

  app.delete(api.trips.delete.path, isAuthenticated, async (req: any, res) => {
    const existing = await storage.getTrip(Number(req.params.id));
    if (!existing || existing.userId !== req.user.claims.sub) {
      return res.status(404).json({ message: 'Trip not found' });
    }
    await storage.deleteTrip(Number(req.params.id));
    res.status(204).send();
  });

  // POIs - Public for now (or authenticated if preferred)
  app.get(api.pois.list.path, isAuthenticated, async (req, res) => {
    const pois = await storage.getPois();
    res.json(pois);
  });

  // Geocoding endpoint - proxies to Photon (Komoot's OSM-based geocoder)
  app.get(api.geocode.lookup.path, isAuthenticated, async (req: any, res) => {
    const address = req.query.address as string;
    if (!address) {
      return res.status(400).json({ message: "Address is required", field: "address" });
    }

    try {
      // Use Photon geocoder - request multiple results to find best match
      const response = await fetch(
        `https://photon.komoot.io/api/?q=${encodeURIComponent(address)}&limit=10`,
        { 
          headers: { 
            'Accept': 'application/json'
          } 
        }
      );
      
      if (!response.ok) {
        console.error('Photon returned status:', response.status);
        return res.status(400).json({ 
          message: "Geocoding service temporarily unavailable. Please wait a moment and try again.",
          field: "address" 
        });
      }
      
      const data = await response.json();
      
      if (data && data.features && data.features.length > 0) {
        // Prioritize city/town results over county/POI results
        const priorityTypes = ['city', 'town', 'village', 'locality', 'hamlet'];
        let bestFeature = data.features[0];
        
        for (const feature of data.features) {
          const type = feature.properties?.type;
          if (priorityTypes.includes(type)) {
            bestFeature = feature;
            break;
          }
        }
        
        const coords = bestFeature.geometry.coordinates;
        const props = bestFeature.properties || {};
        
        // Build a readable address from properties
        const addressParts = [props.name, props.state, props.country].filter(Boolean);
        const displayAddress = addressParts.join(', ') || address;
        
        console.log(`Geocoded "${address}" to ${displayAddress} (${coords[1]}, ${coords[0]}) type: ${props.type}`);
        
        return res.json({
          lat: coords[1], // Photon returns [lng, lat]
          lng: coords[0],
          address: displayAddress
        });
      }
      
      return res.status(400).json({ 
        message: `Could not find location: "${address}". Please try a more specific address.`,
        field: "address" 
      });
    } catch (error) {
      console.error('Geocoding error:', error);
      return res.status(400).json({ 
        message: "Geocoding service unavailable. Please try again.",
        field: "address" 
      });
    }
  });

  // Routing endpoint - uses OSRM for real route distance/time
  app.get(api.routing.calculate.path, isAuthenticated, async (req: any, res) => {
    const { startLat, startLng, endLat, endLng } = req.query;
    
    if (!startLat || !startLng || !endLat || !endLng) {
      return res.status(400).json({ message: "All coordinates are required" });
    }

    try {
      // Use OSRM demo server for routing (production should use own instance)
      const osrmUrl = `https://router.project-osrm.org/route/v1/driving/${startLng},${startLat};${endLng},${endLat}?overview=false`;
      
      const response = await fetch(osrmUrl);
      const data = await response.json();
      
      if (data.code === 'Ok' && data.routes && data.routes.length > 0) {
        const route = data.routes[0];
        // Convert meters to miles and seconds to minutes
        const distanceMiles = Math.round(route.distance * 0.000621371);
        // Add 10% for truck (slower than car routing)
        const durationMinutes = Math.round((route.duration / 60) * 1.1);
        
        return res.json({
          distance: distanceMiles,
          duration: durationMinutes
        });
      }
      
      return res.status(400).json({ message: "Could not calculate route" });
    } catch (error) {
      console.error('Routing error:', error);
      return res.status(400).json({ message: "Routing service unavailable" });
    }
  });

  // User Settings
  app.get(api.settings.get.path, isAuthenticated, async (req: any, res) => {
    const userId = req.user.claims.sub;
    const settings = await storage.getUserSettings(userId);
    res.json(settings || { theme: 'system', totalMilesDriven: 0, totalTimeDriven: 0 });
  });

  app.put(api.settings.update.path, isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const input = api.settings.update.input.parse(req.body);
      const settings = await storage.upsertUserSettings(userId, input);
      res.json(settings);
    } catch (err) {
      if (err instanceof z.ZodError) {
        res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
    }
  });

  // Account deletion
  app.delete(api.account.delete.path, isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      await storage.deleteUserData(userId);
      req.logout((err: any) => {
        if (err) {
          console.error('Logout error:', err);
        }
        req.session.destroy((err: any) => {
          if (err) {
            console.error('Session destroy error:', err);
          }
          res.status(204).send();
        });
      });
    } catch (err) {
      console.error('Account deletion error:', err);
      res.status(500).json({ message: 'Failed to delete account' });
    }
  });

  // Seed Data function
  await seedDatabase();

  return httpServer;
}

async function seedDatabase() {
  const pois = await storage.getPois();
  if (pois.length === 0) {
    console.log("Seeding POIs...");
    await storage.createPoi({
      name: "Pilot Travel Center #456",
      type: "truck_stop",
      location: { lat: 34.0522, lng: -118.2437, address: "123 Highway 1, Los Angeles, CA" },
      amenities: { showers: true, parking: 120, def: true, scales: true },
      rating: 4.5
    });
    await storage.createPoi({
      name: "Love's Travel Stop",
      type: "truck_stop",
      location: { lat: 36.1699, lng: -115.1398, address: "456 Interstate 15, Las Vegas, NV" },
      amenities: { showers: true, parking: 80, def: true, tire_care: true },
      rating: 4.2
    });
    await storage.createPoi({
      name: "I-40 Rest Area Westbound",
      type: "rest_area",
      location: { lat: 35.1983, lng: -111.6513, address: "I-40 Flagstaff, AZ" },
      amenities: { parking: 40, restrooms: true, vending: true },
      rating: 3.8
    });
  }
}
