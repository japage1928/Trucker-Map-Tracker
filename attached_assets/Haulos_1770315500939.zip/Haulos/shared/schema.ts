import { pgTable, text, serial, integer, boolean, timestamp, jsonb, doublePrecision } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { users } from "./models/auth";
import { relations } from "drizzle-orm";

export * from "./models/auth";

// Vehicle Profiles
export const vehicles = pgTable("vehicles", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(), // Links to auth.users.id (which is a string/uuid)
  name: text("name").notNull(),
  type: text("type").notNull().default("semi"), // semi, box, hotshot, etc.
  height: doublePrecision("height").notNull(), // in feet or meters (store consistently, e.g., meters)
  weight: integer("weight").notNull(), // in lbs
  length: doublePrecision("length").notNull(), // in feet
  width: doublePrecision("width").notNull(), // in feet
  hazmat: boolean("hazmat").default(false),
  axleCount: integer("axle_count").default(5),
  createdAt: timestamp("created_at").defaultNow(),
});

// Trips
export const trips = pgTable("trips", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  vehicleId: integer("vehicle_id").notNull(), // FK to vehicles
  name: text("name").notNull(),
  startLocation: jsonb("start_location").notNull(), // { lat: number, lng: number, address: string }
  endLocation: jsonb("end_location").notNull(),   // { lat: number, lng: number, address: string }
  waypoints: jsonb("waypoints").array(),          // Array of location objects
  status: text("status").default("planned"), // planned, active, completed, cancelled
  distance: doublePrecision("distance"), // Estimated distance
  duration: integer("duration"), // Estimated duration in minutes
  createdAt: timestamp("created_at").defaultNow(),
});

// Truck Specific POIs (Stops)
// In a real app, this might come from an external API, but we'll cache/store user saved spots or our own db
export const pois = pgTable("pois", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(), // truck_stop, rest_area, weigh_station, parking
  location: jsonb("location").notNull(), // { lat: number, lng: number, address: string }
  amenities: jsonb("amenities"), // { showers: true, parking_spaces: 50, def: true }
  rating: doublePrecision("rating"),
});

// User Settings and Metrics
export const userSettings = pgTable("user_settings", {
  userId: text("user_id").primaryKey(),
  theme: text("theme").default("system"), // light, dark, system
  totalMilesDriven: doublePrecision("total_miles_driven").default(0),
  totalTimeDriven: integer("total_time_driven").default(0), // in minutes
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Relations
export const vehiclesRelations = relations(vehicles, ({ one, many }) => ({
  trips: many(trips),
}));

export const tripsRelations = relations(trips, ({ one }) => ({
  vehicle: one(vehicles, {
    fields: [trips.vehicleId],
    references: [vehicles.id],
  }),
}));

// Zod Schemas
export const insertVehicleSchema = createInsertSchema(vehicles).omit({ id: true, userId: true, createdAt: true });
export const insertTripSchema = createInsertSchema(trips).omit({ id: true, userId: true, createdAt: true });
export const insertPoiSchema = createInsertSchema(pois).omit({ id: true });
export const insertUserSettingsSchema = createInsertSchema(userSettings).omit({ updatedAt: true });

// Types
export type Vehicle = typeof vehicles.$inferSelect;
export type InsertVehicle = z.infer<typeof insertVehicleSchema>;

export type Trip = typeof trips.$inferSelect;
export type InsertTrip = z.infer<typeof insertTripSchema>;

export type Poi = typeof pois.$inferSelect;
export type InsertPoi = z.infer<typeof insertPoiSchema>;

export type UserSettings = typeof userSettings.$inferSelect;
export type InsertUserSettings = z.infer<typeof insertUserSettingsSchema>;
