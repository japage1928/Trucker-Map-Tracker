import { z } from 'zod';
import { insertVehicleSchema, insertTripSchema, vehicles, trips, pois, userSettings } from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

export const api = {
  vehicles: {
    list: {
      method: 'GET' as const,
      path: '/api/vehicles',
      responses: {
        200: z.array(z.custom<typeof vehicles.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/vehicles',
      input: insertVehicleSchema,
      responses: {
        201: z.custom<typeof vehicles.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/vehicles/:id',
      responses: {
        200: z.custom<typeof vehicles.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    update: {
      method: 'PUT' as const,
      path: '/api/vehicles/:id',
      input: insertVehicleSchema.partial(),
      responses: {
        200: z.custom<typeof vehicles.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    delete: {
      method: 'DELETE' as const,
      path: '/api/vehicles/:id',
      responses: {
        204: z.void(),
        404: errorSchemas.notFound,
      },
    },
  },
  trips: {
    list: {
      method: 'GET' as const,
      path: '/api/trips',
      responses: {
        200: z.array(z.custom<typeof trips.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/trips',
      input: insertTripSchema,
      responses: {
        201: z.custom<typeof trips.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/trips/:id',
      responses: {
        200: z.custom<typeof trips.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    update: {
      method: 'PUT' as const,
      path: '/api/trips/:id',
      input: insertTripSchema.partial(),
      responses: {
        200: z.custom<typeof trips.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    delete: {
      method: 'DELETE' as const,
      path: '/api/trips/:id',
      responses: {
        204: z.void(),
        404: errorSchemas.notFound,
      },
    },
  },
  pois: {
    list: {
      method: 'GET' as const,
      path: '/api/pois',
      input: z.object({
        lat: z.coerce.number().optional(),
        lng: z.coerce.number().optional(),
        radius: z.coerce.number().optional(), // meters
        type: z.string().optional(),
      }).optional(),
      responses: {
        200: z.array(z.custom<typeof pois.$inferSelect>()),
      },
    },
  },
  geocode: {
    lookup: {
      method: 'GET' as const,
      path: '/api/geocode',
      input: z.object({
        address: z.string(),
      }),
      responses: {
        200: z.object({
          lat: z.number(),
          lng: z.number(),
          address: z.string(),
        }),
        400: errorSchemas.validation,
      },
    },
  },
  routing: {
    calculate: {
      method: 'GET' as const,
      path: '/api/route',
      input: z.object({
        startLat: z.coerce.number(),
        startLng: z.coerce.number(),
        endLat: z.coerce.number(),
        endLng: z.coerce.number(),
      }),
      responses: {
        200: z.object({
          distance: z.number(), // miles
          duration: z.number(), // minutes
        }),
        400: errorSchemas.validation,
      },
    },
  },
  settings: {
    get: {
      method: 'GET' as const,
      path: '/api/settings',
      responses: {
        200: z.object({
          theme: z.string().nullable(),
          totalMilesDriven: z.number().nullable(),
          totalTimeDriven: z.number().nullable(),
        }),
      },
    },
    update: {
      method: 'PUT' as const,
      path: '/api/settings',
      input: z.object({
        theme: z.enum(['light', 'dark', 'system']).optional(),
        totalMilesDriven: z.number().optional(),
        totalTimeDriven: z.number().optional(),
      }),
      responses: {
        200: z.custom<typeof userSettings.$inferSelect>(),
      },
    },
  },
  account: {
    delete: {
      method: 'DELETE' as const,
      path: '/api/account',
      responses: {
        204: z.void(),
        500: errorSchemas.internal,
      },
    },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
