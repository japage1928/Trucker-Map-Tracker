# Truck Locations PWA

Phone-first Progressive Web App for storing semi-truck pickup and delivery location intelligence. Local-first, offline-capable, and designed for structured operational data.

## Setup

```bash
npm install
npm run dev
```

## PWA Behavior

- Installable on mobile via the browser install prompt.
- Offline shell supported by the service worker.
- When new content is available, an in-app prompt lets you refresh.

## Data Model

Each location stores:

- Name, address, type, dock type
- Hours, SOP on arrival, parking instructions
- Last-mile route notes, gotchas
- Facility pin and entry/exit pins
- `lastVerified` auto-updated on every edit

## Maps

- OpenStreetMap tiles via Leaflet (no API key required).
- Facility pin plus draggable entry/exit pins.
- Map is for orientation only (no routing or directions).
- Tap the map in detail view to expand full-screen.

## Project Structure

- `src/components` UI blocks and map
- `src/hooks` local state + persistence
- `src/models` TypeScript interfaces
- `src/services` storage and future IndexedDB schema

## Notes

Data persists in localStorage. The IndexedDB schema file is included to prepare for future multi-user sync without adding a backend yet.
