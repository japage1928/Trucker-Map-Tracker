import { useEffect } from 'react'
import { useLocalStorage } from '../hooks/useLocalStorage'

type Theme = 'dark' | 'light'

export default function ThemeToggle() {
  const [theme, setTheme] = useLocalStorage<Theme>('truck-theme', 'dark')

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme)
  }, [theme])

  const nextTheme = theme === 'dark' ? 'light' : 'dark'

  return (
    <button
      className="theme-toggle"
      type="button"
      onClick={() => setTheme(nextTheme)}
      aria-label={`Switch to ${nextTheme} mode`}
    >
      {theme === 'dark' ? 'Light mode' : 'Dark mode'}
    </button>
  )
}
