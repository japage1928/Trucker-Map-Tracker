import { useState } from 'react'
import type { Location } from '../models/location'
import LocationMap from './LocationMap'

interface LocationDetailProps {
  location: Location
  onBack: () => void
  onEdit: () => void
}

export default function LocationDetail({ location, onBack, onEdit }: LocationDetailProps) {
  const [showMap, setShowMap] = useState(false)

  return (
    <section className="panel stack">
      <div className="toolbar">
        <button className="button secondary" type="button" onClick={onBack}>
          Back
        </button>
        <button className="button" type="button" onClick={onEdit}>
          Edit
        </button>
      </div>

      <div className="stack">
        <div className="map-shell">
          <LocationMap
            facilityLat={location.facilityLat}
            facilityLng={location.facilityLng}
            pins={location.pins}
            className="map-shell"
          />
          <div className="map-overlay" onClick={() => setShowMap(true)} />
          <div className="map-badge">Tap to expand</div>
        </div>

        <div className="panel-subtle stack">
          <h2 style={{ margin: 0 }}>{location.name}</h2>
          <p className="card-meta">{location.address}</p>
          <div className="stack">
            <span
              className={`pill ${
                location.locationType === 'pickup'
                  ? ''
                  : location.locationType === 'delivery'
                  ? 'delivery'
                  : 'both'
              }`}
            >
              {location.locationType}
            </span>
            <p className="card-meta">
              Dock: {location.dockType} · Last verified{' '}
              {new Date(location.lastVerified).toLocaleString()}
            </p>
          </div>
        </div>

        <div className="panel-subtle stack">
          <p className="panel-title">Hours</p>
          <p style={{ margin: 0 }}>{location.hoursOfOperation}</p>
        </div>

        <div className="panel-subtle stack">
          <p className="panel-title">Standard Operating Procedure</p>
          <p style={{ margin: 0 }}>{location.sopOnArrival}</p>
        </div>

        <div className="panel-subtle stack">
          <p className="panel-title">Parking</p>
          <p style={{ margin: 0 }}>{location.parkingInstructions}</p>
        </div>

        <div className="panel-subtle stack">
          <p className="panel-title">Last Mile Notes</p>
          <p style={{ margin: 0 }}>{location.lastMileRouteNotes}</p>
        </div>

        <div className="panel-subtle stack">
          <p className="panel-title">Gotchas</p>
          <p style={{ margin: 0 }}>{location.gotchas}</p>
        </div>

        <div className="panel-subtle stack">
          <p className="panel-title">Entry / Exit Pins</p>
          {location.pins.length === 0 ? (
            <p className="card-meta">No pins set.</p>
          ) : (
            <div className="pin-list">
              {location.pins.map((pin) => (
                <div key={pin.id} className="pin-row">
                  <span className="pin-tag">{pin.type}</span>
                  <p style={{ margin: 0 }}>
                    {pin.label} · {pin.instruction}
                  </p>
                  <p className="card-meta">
                    {pin.lat.toFixed(5)}, {pin.lng.toFixed(5)}
                  </p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {showMap && (
        <div className="map-modal">
          <div className="map-modal-header">
            <p className="panel-title">Location Map</p>
            <button className="button secondary" type="button" onClick={() => setShowMap(false)}>
              Close
            </button>
          </div>
          <div className="map-shell fullscreen">
            <LocationMap
              facilityLat={location.facilityLat}
              facilityLng={location.facilityLng}
              pins={location.pins}
              className="map-shell fullscreen"
            />
          </div>
        </div>
      )}
    </section>
  )
}
