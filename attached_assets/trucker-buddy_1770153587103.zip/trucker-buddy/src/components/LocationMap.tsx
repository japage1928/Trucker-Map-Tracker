import { useEffect, useMemo } from 'react'
import { MapContainer, Marker, TileLayer, useMap, useMapEvents } from 'react-leaflet'
import L from 'leaflet'
import type { Pin } from '../models/location'
import { DEFAULT_CENTER } from '../models/location'

const facilityIcon = new L.DivIcon({
  className: 'map-pin facility',
  iconSize: [26, 26],
})

const entryIcon = new L.DivIcon({
  className: 'map-pin',
  iconSize: [20, 20],
})

const exitIcon = new L.DivIcon({
  className: 'map-pin exit',
  iconSize: [20, 20],
})

function resolveCenter(
  facilityLat?: number,
  facilityLng?: number,
  pins?: Pin[],
): [number, number] {
  if (facilityLat !== undefined && facilityLng !== undefined) {
    return [facilityLat, facilityLng]
  }
  if (pins && pins.length > 0) {
    return [pins[0].lat, pins[0].lng]
  }
  return [DEFAULT_CENTER.lat, DEFAULT_CENTER.lng]
}

function AutoFit({
  facilityLat,
  facilityLng,
  pins,
}: {
  facilityLat?: number
  facilityLng?: number
  pins: Pin[]
}) {
  const map = useMap()

  const bounds = useMemo(() => {
    const coords: [number, number][] = []
    if (facilityLat !== undefined && facilityLng !== undefined) {
      coords.push([facilityLat, facilityLng])
    }
    pins.forEach((pin) => coords.push([pin.lat, pin.lng]))
    if (coords.length === 0) {
      return null
    }
    return L.latLngBounds(coords)
  }, [facilityLat, facilityLng, pins])

  useEffect(() => {
    if (bounds) {
      map.fitBounds(bounds.pad(0.2))
    }
  }, [bounds, map])

  return null
}

function MapClickHandler({
  enabled,
  onClick,
}: {
  enabled: boolean
  onClick: (lat: number, lng: number) => void
}) {
  useMapEvents({
    click: (event) => {
      if (enabled) {
        onClick(event.latlng.lat, event.latlng.lng)
      }
    },
  })
  return null
}

interface LocationMapProps {
  facilityLat?: number
  facilityLng?: number
  pins: Pin[]
  editable?: boolean
  onFacilityChange?: (lat: number, lng: number) => void
  onPinMove?: (id: string, lat: number, lng: number) => void
  placingFacility?: boolean
  className?: string
}

export default function LocationMap({
  facilityLat,
  facilityLng,
  pins,
  editable = false,
  onFacilityChange,
  onPinMove,
  placingFacility = false,
  className,
}: LocationMapProps) {
  const center = resolveCenter(facilityLat, facilityLng, pins)
  const zoom = facilityLat !== undefined && facilityLng !== undefined ? 15 : 4

  return (
    <MapContainer center={center} zoom={zoom} scrollWheelZoom className={className}>
      <TileLayer
        attribution="&copy; OpenStreetMap contributors"
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />

      <AutoFit facilityLat={facilityLat} facilityLng={facilityLng} pins={pins} />

      {facilityLat !== undefined && facilityLng !== undefined && (
        <Marker
          position={[facilityLat, facilityLng]}
          icon={facilityIcon}
          draggable={editable && !!onFacilityChange}
          eventHandlers={{
            dragend: (event) => {
              if (!onFacilityChange) return
              const marker = event.target as L.Marker
              const position = marker.getLatLng()
              onFacilityChange(position.lat, position.lng)
            },
          }}
        />
      )}

      {pins.map((pin) => (
        <Marker
          key={pin.id}
          position={[pin.lat, pin.lng]}
          icon={pin.type === 'entry' ? entryIcon : exitIcon}
          draggable={editable}
          eventHandlers={{
            dragend: (event) => {
              if (!onPinMove) return
              const marker = event.target as L.Marker
              const position = marker.getLatLng()
              onPinMove(pin.id, position.lat, position.lng)
            },
          }}
        />
      ))}

      {onFacilityChange && (
        <MapClickHandler
          enabled={placingFacility}
          onClick={(lat, lng) => onFacilityChange(lat, lng)}
        />
      )}
    </MapContainer>
  )
}
