import { useRegisterSW } from 'virtual:pwa-register/react'

export default function PwaUpdatePrompt() {
  const { needRefresh, updateServiceWorker } = useRegisterSW({
    onRegistered(r: ServiceWorkerRegistration | undefined) {
      r?.update()
    },
  })

  if (!needRefresh) {
    return null
  }

  return (
    <div className="pwa-banner">
      <p>New offline content is available. Update to refresh the app shell.</p>
      <button className="button" type="button" onClick={() => updateServiceWorker(true)}>
        Update Now
      </button>
    </div>
  )
}
