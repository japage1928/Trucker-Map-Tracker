import type { Location } from '../models/location'

interface LocationListProps {
  locations: Location[]
  onSelect: (id: string) => void
  onCreate: () => void
}

export default function LocationList({ locations, onSelect, onCreate }: LocationListProps) {
  return (
    <section className="panel stack">
      <div className="toolbar">
        <div>
          <p className="panel-title">Locations</p>
          <p className="card-meta">{locations.length} saved location(s)</p>
        </div>
        <button className="button" type="button" onClick={onCreate}>
          Add Location
        </button>
      </div>

      {locations.length === 0 ? (
        <div className="empty">
          <p>No locations yet.</p>
          <p>Add your first pickup or delivery site.</p>
        </div>
      ) : (
        <div className="list-grid">
          {locations.map((location) => (
            <div key={location.id} className="card" onClick={() => onSelect(location.id)}>
              <p className="card-title">{location.name}</p>
              <p className="card-meta">{location.address}</p>
              <div className="stack" style={{ marginTop: '0.75rem' }}>
                <span
                  className={`pill ${
                    location.locationType === 'pickup'
                      ? ''
                      : location.locationType === 'delivery'
                      ? 'delivery'
                      : 'both'
                  }`}
                >
                  {location.locationType}
                </span>
                <p className="card-meta">
                  Last verified {new Date(location.lastVerified).toLocaleDateString()}
                </p>
              </div>
            </div>
          ))}
        </div>
      )}
    </section>
  )
}
