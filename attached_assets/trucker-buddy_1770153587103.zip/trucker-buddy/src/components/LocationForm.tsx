import { useMemo, useState } from 'react'
import { v4 as uuid } from 'uuid'
import type { Location, LocationInput, Pin, PinType } from '../models/location'
import { DEFAULT_CENTER } from '../models/location'
import LocationMap from './LocationMap'

interface LocationFormProps {
  title: string
  initial?: Location
  onSave: (input: LocationInput) => void
  onCancel: () => void
}

const EMPTY_INPUT: LocationInput = {
  name: '',
  address: '',
  locationType: 'pickup',
  hoursOfOperation: '',
  sopOnArrival: '',
  parkingInstructions: '',
  dockType: 'live',
  lastMileRouteNotes: '',
  gotchas: '',
  pins: [],
  facilityLat: undefined,
  facilityLng: undefined,
}

export default function LocationForm({ title, initial, onSave, onCancel }: LocationFormProps) {
  const initialInput: LocationInput | null = initial
    ? {
        name: initial.name,
        address: initial.address,
        locationType: initial.locationType,
        hoursOfOperation: initial.hoursOfOperation,
        sopOnArrival: initial.sopOnArrival,
        parkingInstructions: initial.parkingInstructions,
        dockType: initial.dockType,
        lastMileRouteNotes: initial.lastMileRouteNotes,
        gotchas: initial.gotchas,
        pins: initial.pins,
        facilityLat: initial.facilityLat,
        facilityLng: initial.facilityLng,
      }
    : null

  const [form, setForm] = useState<LocationInput>(() => ({
    ...EMPTY_INPUT,
    ...(initialInput ?? {}),
  }))
  const [placingFacility, setPlacingFacility] = useState(false)

  const facilityCenter = useMemo(() => {
    if (form.facilityLat !== undefined && form.facilityLng !== undefined) {
      return { lat: form.facilityLat, lng: form.facilityLng }
    }
    if (form.pins.length > 0) {
      return { lat: form.pins[0].lat, lng: form.pins[0].lng }
    }
    return DEFAULT_CENTER
  }, [form.facilityLat, form.facilityLng, form.pins])

  const updateField = <K extends keyof LocationInput>(key: K, value: LocationInput[K]) => {
    setForm((prev) => ({ ...prev, [key]: value }))
  }

  const handleAddPin = (type: PinType) => {
    const pin: Pin = {
      id: uuid(),
      type,
      lat: facilityCenter.lat,
      lng: facilityCenter.lng,
      label: type === 'entry' ? 'Gate A' : 'Exit A',
      instruction: type === 'entry' ? 'Use right lane' : 'Merge left',
    }
    setForm((prev) => ({ ...prev, pins: [...prev.pins, pin] }))
  }

  const handlePinChange = (id: string, patch: Partial<Pin>) => {
    setForm((prev) => ({
      ...prev,
      pins: prev.pins.map((pin) => (pin.id === id ? { ...pin, ...patch } : pin)),
    }))
  }

  const handlePinRemove = (id: string) => {
    setForm((prev) => ({ ...prev, pins: prev.pins.filter((pin) => pin.id !== id) }))
  }

  const handleSubmit = (event: React.FormEvent) => {
    event.preventDefault()
    onSave(form)
  }

  return (
    <form className="panel stack" onSubmit={handleSubmit}>
      <div className="toolbar">
        <div>
          <p className="panel-title">{title}</p>
          <p className="card-meta">All fields required.</p>
        </div>
        <div className="pin-actions">
          <button className="button secondary" type="button" onClick={onCancel}>
            Cancel
          </button>
          <button className="button" type="submit">
            Save Location
          </button>
        </div>
      </div>

      <div className="field-grid">
        <div className="field">
          <label htmlFor="name">Name</label>
          <input
            id="name"
            value={form.name}
            onChange={(event) => updateField('name', event.target.value)}
            required
          />
        </div>
        <div className="field">
          <label htmlFor="address">Address</label>
          <input
            id="address"
            value={form.address}
            onChange={(event) => updateField('address', event.target.value)}
            required
          />
        </div>
        <div className="field">
          <label htmlFor="locationType">Location Type</label>
          <select
            id="locationType"
            value={form.locationType}
            onChange={(event) =>
              updateField('locationType', event.target.value as LocationInput['locationType'])
            }
            required
          >
            <option value="pickup">Pickup</option>
            <option value="delivery">Delivery</option>
            <option value="both">Both</option>
          </select>
        </div>
        <div className="field">
          <label htmlFor="dockType">Dock Type</label>
          <select
            id="dockType"
            value={form.dockType}
            onChange={(event) =>
              updateField('dockType', event.target.value as LocationInput['dockType'])
            }
            required
          >
            <option value="live">Live</option>
            <option value="drop">Drop</option>
            <option value="mixed">Mixed</option>
          </select>
        </div>
      </div>

      <div className="field-grid">
        <div className="field">
          <label htmlFor="hoursOfOperation">Hours of Operation</label>
          <textarea
            id="hoursOfOperation"
            value={form.hoursOfOperation}
            onChange={(event) => updateField('hoursOfOperation', event.target.value)}
            required
          />
        </div>
        <div className="field">
          <label htmlFor="sopOnArrival">SOP on Arrival</label>
          <textarea
            id="sopOnArrival"
            value={form.sopOnArrival}
            onChange={(event) => updateField('sopOnArrival', event.target.value)}
            required
          />
        </div>
      </div>

      <div className="field-grid">
        <div className="field">
          <label htmlFor="parkingInstructions">Parking Instructions</label>
          <textarea
            id="parkingInstructions"
            value={form.parkingInstructions}
            onChange={(event) => updateField('parkingInstructions', event.target.value)}
            required
          />
        </div>
        <div className="field">
          <label htmlFor="lastMileRouteNotes">Last Mile Route Notes</label>
          <textarea
            id="lastMileRouteNotes"
            value={form.lastMileRouteNotes}
            onChange={(event) => updateField('lastMileRouteNotes', event.target.value)}
            required
          />
        </div>
      </div>

      <div className="field-grid">
        <div className="field">
          <label htmlFor="gotchas">Gotchas</label>
          <textarea
            id="gotchas"
            value={form.gotchas}
            onChange={(event) => updateField('gotchas', event.target.value)}
            required
          />
        </div>
      </div>

      <div className="panel-subtle stack">
        <div className="toolbar">
          <div>
            <p className="panel-title">Facility Map</p>
            <p className="card-meta">Tap the map to place or drag pins.</p>
          </div>
          <div className="pin-actions">
            <button
              className="button secondary"
              type="button"
              onClick={() => setPlacingFacility((prev) => !prev)}
            >
              {placingFacility ? 'Placing Facility' : 'Place Facility Pin'}
            </button>
            <button
              className="button ghost"
              type="button"
              onClick={() => {
                updateField('facilityLat', undefined)
                updateField('facilityLng', undefined)
              }}
            >
              Clear Facility
            </button>
          </div>
        </div>
        <div className="map-shell">
          <LocationMap
            facilityLat={form.facilityLat}
            facilityLng={form.facilityLng}
            pins={form.pins}
            editable
            placingFacility={placingFacility}
            onFacilityChange={(lat, lng) => {
              updateField('facilityLat', lat)
              updateField('facilityLng', lng)
              setPlacingFacility(false)
            }}
            onPinMove={(id, lat, lng) => handlePinChange(id, { lat, lng })}
            className="map-shell"
          />
        </div>
      </div>

      <div className="panel-subtle stack">
        <div className="toolbar">
          <div>
            <p className="panel-title">Entry / Exit Pins</p>
            <p className="card-meta">Pins belong to this location only.</p>
          </div>
          <div className="pin-actions">
            <button className="button secondary" type="button" onClick={() => handleAddPin('entry')}>
              Add Entry Pin
            </button>
            <button className="button secondary" type="button" onClick={() => handleAddPin('exit')}>
              Add Exit Pin
            </button>
          </div>
        </div>

        {form.pins.length === 0 ? (
          <p className="card-meta">No pins yet.</p>
        ) : (
          <div className="pin-list">
            {form.pins.map((pin) => (
              <div key={pin.id} className="pin-row">
                <div className="field-grid">
                  <div className="field">
                    <label>Type</label>
                    <select
                      value={pin.type}
                      onChange={(event) =>
                        handlePinChange(pin.id, { type: event.target.value as PinType })
                      }
                    >
                      <option value="entry">Entry</option>
                      <option value="exit">Exit</option>
                    </select>
                  </div>
                  <div className="field">
                    <label>Label</label>
                    <input
                      value={pin.label}
                      onChange={(event) => handlePinChange(pin.id, { label: event.target.value })}
                      required
                    />
                  </div>
                </div>
                <div className="field">
                  <label>Instruction</label>
                  <input
                    value={pin.instruction}
                    onChange={(event) =>
                      handlePinChange(pin.id, { instruction: event.target.value })
                    }
                    required
                  />
                </div>
                <p className="card-meta">
                  {pin.lat.toFixed(5)}, {pin.lng.toFixed(5)}
                </p>
                <button
                  className="button ghost"
                  type="button"
                  onClick={() => handlePinRemove(pin.id)}
                >
                  Remove Pin
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </form>
  )
}
