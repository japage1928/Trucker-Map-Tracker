import { createContext, useContext, useEffect, useMemo, useState } from 'react'
import { v4 as uuid } from 'uuid'
import type { Location, LocationInput } from '../models/location'
import { loadLocations, saveLocations } from '../services/storage'

interface LocationsContextValue {
  locations: Location[]
  createLocation: (input: LocationInput) => Location
  updateLocation: (id: string, input: LocationInput) => void
}

const LocationsContext = createContext<LocationsContextValue | null>(null)

export function LocationsProvider({ children }: { children: React.ReactNode }) {
  const [locations, setLocations] = useState<Location[]>(() => loadLocations())

  useEffect(() => {
    saveLocations(locations)
  }, [locations])

  const value = useMemo<LocationsContextValue>(() => {
    const createLocation = (input: LocationInput) => {
      const created: Location = {
        ...input,
        id: uuid(),
        lastVerified: new Date().toISOString(),
      }
      setLocations((prev) => [created, ...prev])
      return created
    }

    const updateLocation = (id: string, input: LocationInput) => {
      setLocations((prev) =>
        prev.map((location) =>
          location.id === id
            ? {
                ...location,
                ...input,
                lastVerified: new Date().toISOString(),
              }
            : location,
        ),
      )
    }

    return { locations, createLocation, updateLocation }
  }, [locations])

  return <LocationsContext.Provider value={value}>{children}</LocationsContext.Provider>
}

export function useLocations() {
  const context = useContext(LocationsContext)
  if (!context) {
    throw new Error('useLocations must be used within LocationsProvider')
  }
  return context
}
