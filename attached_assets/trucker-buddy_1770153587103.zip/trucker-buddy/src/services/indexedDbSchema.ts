export const DB_NAME = 'truck-locations'
export const DB_VERSION = 1

export const STORE_LOCATIONS = 'locations'
export const STORE_METADATA = 'metadata'

export interface StoredLocationRecord {
  id: string
  ownerId: string
  updatedAt: string
  payload: unknown
}

export interface MetadataRecord {
  key: string
  value: string
}
