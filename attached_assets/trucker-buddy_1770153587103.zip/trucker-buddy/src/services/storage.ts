import type { Location } from '../models/location'

const STORAGE_KEY = 'truck-locations:v1'

interface StoredPayload {
  version: 1
  ownerId: string
  updatedAt: string
  locations: Location[]
}

const EMPTY_PAYLOAD: StoredPayload = {
  version: 1,
  ownerId: 'local',
  updatedAt: new Date(0).toISOString(),
  locations: [],
}

export function loadLocations(): Location[] {
  if (typeof window === 'undefined') {
    return []
  }
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY)
    if (!raw) {
      return []
    }
    const parsed = JSON.parse(raw) as StoredPayload
    return Array.isArray(parsed.locations) ? parsed.locations : []
  } catch {
    return []
  }
}

export function saveLocations(locations: Location[]) {
  if (typeof window === 'undefined') {
    return
  }
  const payload: StoredPayload = {
    ...EMPTY_PAYLOAD,
    updatedAt: new Date().toISOString(),
    locations,
  }
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(payload))
  } catch {
    // Ignore storage write errors (private mode / quota).
  }
}
