export type LocationType = 'pickup' | 'delivery' | 'both';
export type DockType = 'live' | 'drop' | 'mixed';
export type PinType = 'entry' | 'exit';

export interface Pin {
  id: string;
  type: PinType;
  lat: number;
  lng: number;
  label: string;
  instruction: string;
}

export interface Location {
  id: string;
  name: string;
  address: string;
  locationType: LocationType;
  hoursOfOperation: string;
  sopOnArrival: string;
  parkingInstructions: string;
  dockType: DockType;
  lastMileRouteNotes: string;
  gotchas: string;
  lastVerified: string;
  pins: Pin[];
  facilityLat?: number;
  facilityLng?: number;
}

export type LocationInput = Omit<Location, 'id' | 'lastVerified'>;

export const DEFAULT_CENTER = { lat: 39.8283, lng: -98.5795 };
