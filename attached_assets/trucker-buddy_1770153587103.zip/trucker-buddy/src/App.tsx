import { useMemo, useState } from 'react'
import './App.css'
import LocationDetail from './components/LocationDetail'
import LocationForm from './components/LocationForm'
import LocationList from './components/LocationList'
import PwaUpdatePrompt from './components/PwaUpdatePrompt'
import ThemeToggle from './components/ThemeToggle'
import { LocationsProvider, useLocations } from './hooks/useLocations'
import type { LocationInput } from './models/location'

type ViewState =
  | { mode: 'list' }
  | { mode: 'detail'; id: string }
  | { mode: 'create' }
  | { mode: 'edit'; id: string }

function AppContent() {
  const { locations, createLocation, updateLocation } = useLocations()
  const [view, setView] = useState<ViewState>({ mode: 'list' })

  const activeLocation = useMemo(() => {
    if (view.mode === 'detail' || view.mode === 'edit') {
      return locations.find((location) => location.id === view.id) ?? null
    }
    return null
  }, [locations, view])

  const handleSave = (input: LocationInput) => {
    if (view.mode === 'edit' && view.id) {
      updateLocation(view.id, input)
      setView({ mode: 'detail', id: view.id })
      return
    }

    const created = createLocation(input)
    setView({ mode: 'detail', id: created.id })
  }

  return (
    <div className="app">
      <header className="app-header">
        <div className="brand">
          <div className="brand-mark" />
          <div>
            <p className="brand-title">Truck Locations</p>
            <p className="brand-subtitle">Local-first pickup & delivery intel</p>
          </div>
        </div>
        <ThemeToggle />
      </header>

      <main className="app-main">
        {view.mode === 'list' && (
          <LocationList
            locations={locations}
            onSelect={(id) => setView({ mode: 'detail', id })}
            onCreate={() => setView({ mode: 'create' })}
          />
        )}

        {view.mode === 'detail' && activeLocation && (
          <LocationDetail
            location={activeLocation}
            onBack={() => setView({ mode: 'list' })}
            onEdit={() => setView({ mode: 'edit', id: activeLocation.id })}
          />
        )}

        {view.mode === 'edit' && activeLocation && (
          <LocationForm
            title="Edit Location"
            initial={activeLocation}
            onCancel={() => setView({ mode: 'detail', id: activeLocation.id })}
            onSave={handleSave}
          />
        )}

        {view.mode === 'create' && (
          <LocationForm
            title="New Location"
            onCancel={() => setView({ mode: 'list' })}
            onSave={handleSave}
          />
        )}
      </main>

      <PwaUpdatePrompt />
    </div>
  )
}

export default function App() {
  return (
    <LocationsProvider>
      <AppContent />
    </LocationsProvider>
  )
}
